import React, { createContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const UserContext = createContext();

export default function UserContextProvider(props) {
  const [users, setUsers] = useState([]);
  const [allCards, setAllCards] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [allCars, setAllCars] = useState([]); // New state for cars
  const [expoPushToken, setExpoPushToken] = useState('');


  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const response = await fetch('https://socialgarage.onrender.com/api/users');
        const data = await response.json();
        setUsers(data);
      } catch (error) {
        console.error(error);
      }
    };
    loadUsers();
  }, []);

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  useEffect(() => {
    const loadAllCars = async () => {
      try {
        const response = await fetch('https://socialgarage.onrender.com/api/users/allCars'); // Change the URL to the cars endpoint
        const data = await response.json();
        setAllCars(data);
      } catch (error) {
        console.error(error);
      }
    };
    loadAllCars();
  }, []);




  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  useEffect(() => {
    const updateUsers = async () => {
      try {
        await fetch('https://socialgarage.onrender.com/api/users', {
          method: 'PUT',
          headers: {
            'Content-type': 'application/json; charset=UTF-8',
            'Accept': 'application/json; charset=UTF-8',
          },
          body: JSON.stringify(users),
        });
      } catch (error) {
        console.error(error);
      }
    };
    updateUsers();
  }, [users]);





  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const fromRegisterToUsersList = async (email, password, name, profileImage) => {
    const newUser = { email: email.toLowerCase(), password, name, profileImage, followers: [], following: [], cars: [] };
    try {
      const response = await fetch('https://socialgarage.onrender.com/api/users/add', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(newUser),
      });
      if (response.status === 201) {
        setUsers([...users, newUser]);
        return true; // User added successfully
      }
      else if (response.status === 408) {
        alert("מייל תפוס")
        return false;
      }

      else if (response.status === 409) {
        alert("כינוי תפוס")
        return false;
      }
      else{
        alert("שגיאה")
        return false;

      }

    }
    catch (error) {
      console.error(error);
    }
    return false; // Failed to add user
  };




  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const fromLoginToCheckIfExist = async (userEmail, password) => {
    try {
      const response = await fetch('https://socialgarage.onrender.com/api/users/login', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ email: userEmail.toLowerCase(), password }),
      });

      if (response.status === 200) {
        const user = await response.json();
        setCurrentUser(user);
        // Save the user data to AsyncStorage (local storage) for persistent login
        // await AsyncStorage.setItem('currentUser', JSON.stringify(user));
        const carsResponse = await fetch('https://socialgarage.onrender.com/api/cards/cards');
        const carsData = await carsResponse.json();
        setAllCards(carsData);

        return true; // Authentication successful
      } else if (response.status === 404) {
        return false; // User not found
      } else if (response.status === 401) {
        return false; // Invalid credentials
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };



  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const addCarToUser = async (newCar) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/addcar`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ car: newCar }),
      });

      if (response.status === 409) {
        alert("הרכב נמצא אצל משתמש אחר, אנא צור קשר במידה והרכב בבעלותך")
        return true;
      }

      if (response.status === 200) {
        const updatedUser = await response.json();
        setCurrentUser(updatedUser);
        return true; // Car added successfully
      } else {
        return false; // Failed to add car
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const addMaintenanceToUser = async (carNumber, newMaintenance) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/addMaintenance`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ carNumber, newMaintenance }),
      });

      if (response.status === 200) {
        const updatedUser = await response.json();
        setCurrentUser(updatedUser);
        return true; // Maintenance added successfully
      } else {
        return false; // Failed to add maintenance
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };


  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const transferCar = async (newOwnerEmail, carNumber) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/transferCar`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ email: newOwnerEmail, carNumber }),
      });

      if (response.status === 200) {
        const { updatedUser, updatedNewOwner } = await response.json();
        setCurrentUser(updatedUser);
        return true; // Car transferred successfully
      } else {
        return false; // Failed to transfer car
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };



  const transferCarNumberInCard = async (carNumber, newOwnerId, newOwnerName, newProfileImage) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/cards/update-owner-info`, {

        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          carNumber: carNumber,
          newOwnerId: newOwnerId,
          newOwnerName: newOwnerName,
          newProfileImage: newProfileImage,
        }),
      });



      if (response.status === 200) {
        const updateResponse = await fetch(`https://socialgarage.onrender.com/api/users/${carNumber}/updateCards`, {
          method: 'PUT',
          headers: {
            'Content-type': 'application/json; charset=UTF-8',
            'Accept': 'application/json; charset=UTF-8',
          },
          body: JSON.stringify({
            newOwnerId: newOwnerId,
            newOwnerName: newOwnerName,
            newProfileImage: newProfileImage,
          }),
        });

        if (updateResponse.status === 200) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  };

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const deleteCar = async (newOwnerEmail, carNumber) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/transferCar`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ email: newOwnerEmail, carNumber }),
      });

      if (response.status === 200) {
        const { updatedUser, updatedNewOwner } = await response.json();
        setCurrentUser(updatedUser);
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  };

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const updateCarMileage = async (carNumber, mileage) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/mileage`, {
        method: 'PUT',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ carNumber, mileage }),
      });

      if (response.status === 200) {
        const updatedUser = await response.json();
        setCurrentUser(updatedUser);
        return true; // Mileage updated successfully
      } else {
        return false; // Failed to update mileage
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const updateCarTest = async (carNumber, testValidity) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/test`, {
        method: 'PUT',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ carNumber, testValidity }),
      });

      if (response.status === 200) {
        const updatedUser = await response.json();
        setCurrentUser(updatedUser);
        return true; // Test validity updated successfully
      } else {
        return false; // Failed to update test validity
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  const SendMail = async (email) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/sendMailWithKey`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ email }),
      });

      if (response.status === 200) {
        const data = await response.json();
        return data.key;
      } else {
        return false;
      }
    } catch (error) {
      console.error(error);
      return false;
    }
  };
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */




  const addCardToCar = async (carNumber, newCard) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/addCardToCar`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ carNumber, newCard }),
      });


      const data = await response.json();

      if (response.ok) {
        setCurrentUser(data);
        return true;
      } else {
        console.log(data.error);
        return false;
      }
    } catch (error) {
      console.log('Error:', error.message);
      return false;
    }
  };
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const changeToPublic = async (carNumber) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/makeCarPublic/${carNumber}`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
      });


      const data = await response.json();

      if (response.ok) {
        setCurrentUser(data);
        return true;
      } else {
        console.log(data.error);
        return false;
      }
    } catch (error) {
      console.log('Error:', error.message);
      return false;
    }
  };


  const changeToPrivate = async (carNumber) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/makeCarPrivate/${carNumber}`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
      });
      const data = await response.json();
      if (response.ok) {
        setCurrentUser(data);
        return true;
      } else {
        console.log(data.error);
        return false;
      }
    } catch (error) {
      console.log('Error:', error.message);
      return false;
    }
  };

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const updateSaleDetails = async (carNumber, price, detailsOfSale) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/addSaleDetails`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ carNumber, price, detailsOfSale }),
      });

      if (response.status === 200) {

        const updatedUser = await response.json();
        setCurrentUser(updatedUser);
        return true; // Sale details updated successfully
      } else {
        return false; // Failed to update sale details
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };

  const updateIsForSaleTrueInCard = async (carNumber) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/cards/set-for-sale/${carNumber}`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({}),
      });

      if (response.status === 200) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };





  const removeSaleDetailsFromCar = async (carNumber) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/removeSaleDetails/${carNumber}`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({}), // Empty body since the carNumber is already in the URL
      });

      if (response.status === 200) {
        const updatedUser = await response.json();
        setCurrentUser(updatedUser);
        return true; // Sale details removed successfully
      } else {
        return false; // Failed to remove sale details
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };



  const updateIsForSaleFalseInCard = async (carNumber) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/cards/set-not-for-sale/${carNumber}`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({}),
      });

      if (response.status === 200) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const editSaleDetails = async (carNumber, price, detailsOfSale) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/editSaleDetails/${carNumber}`, {
        method: 'PUT',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ price, detailsOfSale }),
      });

      if (response.status === 200) {
        const updatedUser = await response.json();
        setCurrentUser(updatedUser);
        return true; // Sale details updated successfully
      } else {
        return false; // Failed to update sale details
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };





  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CARDS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  useEffect(() => {
    const loadAllCards = async () => {
      try {
        const response = await fetch('https://socialgarage.onrender.com/api/cards/cards');
        const data = await response.json();
        setAllCards(JSON.stringify(data));
      } catch (error) {
        console.error(error);
      }
    };
    loadAllCards();
  }, []);



  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const addNewCard = async (newCard) => {
    try {
      const response = await fetch('https://socialgarage.onrender.com/api/cards/add', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(newCard),
      });

      if (response.ok) {
        const newCard = await response.json();
        setAllCards([...allCards, newCard]);
        return true; // Card added successfully
      } else {
        return false; // Failed to add card
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const likeCard = async (cardId) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/cards/${cardId}/like/${currentUser._id}`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({}), // Empty body since the cardId is already in the URL
      });

      if (response.status === 200) {
        const updatedCard = await response.json();
        // Update the "allCards" state with the updated card data
        setAllCards((prevCards) => prevCards.map((card) => card._id === cardId ? updatedCard : card));
        return updatedCard; // Card liked successfully
      } else if (response.status === 400) {
        const errorData = await response.json();
        return { error: errorData.error };
      } else {
        return false; // Failed to like card
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };

  const likeCardOfUser = async (ownerId, carNumber, cardId) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${ownerId}/${carNumber}/increaseLikes/${cardId}/${currentUser._id}`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({}),
      });

      if (response.status === 200) {
        return true;
      } else if (response.status === 400) {
        return false;
      } else {
        return false;
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };



  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const addCommentToCard = async (cardId, commentData) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/cards/${cardId}/add-comment`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(commentData),
      });

      if (response.status === 200) {
        const updatedCard = await response.json();
        // Update the "allCards" state with the updated card data
        setAllCards((prevCards) => prevCards.map((card) => card._id === cardId ? updatedCard : card));
        return true; // Comment added successfully
      } else if (response.status === 404) {
        return { error: 'Card not found' };
      } else {
        return false; // Failed to add comment
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

  const addCommentToUser = async (userId, carNumber, cardId, commentData) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${userId}/${carNumber}/${cardId}/add-comment`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(commentData),
      });

      if (response.status === 200) {
        const updatedCard = await response.json();
        return true; // Comment added successfully
      } else if (response.status === 404) {
        return { error: 'Card not found' };
      } else {
        return false; // Failed to add comment
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };

  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


  const deleteCardsByCarNumber = async (carNumber) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/cards/delete-by-carNumber/${carNumber}`, {
        method: 'DELETE',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
      });

      if (response.ok) {
        // Remove the deleted cards from the "allCards" state
        setAllCards((prevCards) => prevCards.filter((card) => card.carNumber !== carNumber));
        return true; // Cards deleted successfully
      } else {
        return false; // Failed to delete cards
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };



  const uploadTheLastAfterPublic = async (newCard) => {
    try {
      const response = await fetch('https://socialgarage.onrender.com/api/cards/add', {
        method: 'POST',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(newCard),
      });

      if (response.ok) {
        const newCard = await response.json();
        setAllCards([...allCards, newCard]);
        return true; // Card added successfully
      } else {
        return false; // Failed to add card
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };


  const removeCardFromCurrentUser = async (cardId) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/removeCard/${cardId}`, {
        method: 'DELETE',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
      });

      if (response.status === 200) {
        const updatedUser = await response.json();
        setCurrentUser(updatedUser);
        return true; // Card removed successfully
      } else {
        return false; // Failed to remove card
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };


  const deleteCardById = async (cardId) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/cards/${cardId}`, {
        method: 'DELETE',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
      });

      if (response.status === 200) {
        // Remove the deleted card from the "allCards" state
        setAllCards((prevCards) => prevCards.filter((card) => card._id !== cardId));
        return true; // Card deleted successfully
      } else {
        return false; // Failed to delete card
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };


  const updateImageCar = async (carNumber, image) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/updateCarImage/${carNumber}`, {
        method: 'PUT',
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
          'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ image }),
      });

      if (response.status === 200) {

        setAllCars((prevCars) =>
          prevCars.map((car) =>
            car.carNumber === carNumber
              ? { ...car, image: image } // Update the image property
              : car
          )
        );

        const updatedUser = await response.json();
        setCurrentUser(updatedUser);

        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error(error);
      return false; // Error occurred
    }
  };


  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
  /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */





  return (
    <UserContext.Provider value={{ updateImageCar, deleteCardById, removeCardFromCurrentUser, setCurrentUser, expoPushToken, setExpoPushToken, editSaleDetails, updateIsForSaleFalseInCard, updateIsForSaleTrueInCard, removeSaleDetailsFromCar, updateSaleDetails, transferCarNumberInCard, allCars, users, addCommentToUser, likeCardOfUser, uploadTheLastAfterPublic, deleteCardsByCarNumber, changeToPrivate, changeToPublic, addCommentToCard, addCardToCar, likeCard, setAllCards, addNewCard, allCards, SendMail, updateCarTest, updateCarMileage, deleteCar, currentUser, transferCar, addMaintenanceToUser, addCarToUser, fromRegisterToUsersList, fromLoginToCheckIfExist }}>
      {props.children}
    </UserContext.Provider>
  );
}
