import React, { useContext, useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Dimensions, Modal, Alert } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import CommentModalToProfile from './CommentModalToProfile';
import { useNavigation } from '@react-navigation/native';

const EachCardPost = ({ route }) => {
    const navigation = useNavigation();
    const { cardData } = route.params;
    const { likeCard, currentUser, likeCardOfUser, removeCardFromCurrentUser, deleteCardById } = useContext(UserContext);
    const [likes, setLikes] = useState(cardData.likes);
    const [isCommentsModalOpen, setIsCommentsModalOpen] = useState(false);

    const [selectedCarComments, setSelectedCarComments] = useState(null);
    const [selectedCardId, setSelectedCardId] = useState(null);
    const [imageHeights, setImageHeights] = useState({});

    const toggleCommentsModal = () => {
        setIsCommentsModalOpen(!isCommentsModalOpen);
    };

    const openCommentsModal = (comments, card) => {
        setSelectedCarComments(comments);
        setSelectedCardId(card);
    };

    const closeCommentsModal = () => {
        setSelectedCarComments(null);
    };

    const updateComments = (updatedComments) => {
        setSelectedCarComments(updatedComments);
        cardData.comments = updatedComments;
    };

    const handleLike = async () => {
        likeCardOfUser(cardData.owner.id, cardData.carNumber, cardData._id);
        const card = await likeCard(cardData._id);
        setLikes(card.likes);
    };

    const determineImageHeight = (imageUri) => {
        Image.getSize(imageUri, (width, height) => {
            if (height > width) {
                setImageHeights((prevHeights) => ({
                    ...prevHeights,
                    [imageUri]: 520,
                }));
            } else {
                setImageHeights((prevHeights) => ({
                    ...prevHeights,
                    [imageUri]: 260,
                }));
            }
        });
    };

    useEffect(() => {
        determineImageHeight(cardData.image);
    }, []);

    const [isKebabMenuVisible, setIsKebabMenuVisible] = useState(false);
    const [selectedOption, setSelectedOption] = useState(null);

    const toggleKebabMenu = () => {
        setIsKebabMenuVisible(!isKebabMenuVisible);
    };

    const closeKebabMenu = () => {
        setIsKebabMenuVisible(false);
    };



    const handleDeleteKebab = () => {
        // Show an alert to confirm the delete action
        Alert.alert(
            'מחיקת פוסט',
            'האם אתה בטוח שברצונך למחוק את התמונה?',
            [
                {
                    text: 'No',
                    style: 'cancel', // The 'No' button will cancel the delete action
                },
                {
                    text: 'Yes',
                    onPress: async () => { // Use async here
                        // User pressed 'Yes', so delete the post
                        setIsKebabMenuVisible(false); // Close the menu
                        try {
                            const success = await removeCardFromCurrentUser(cardData._id); // Call your remove function here
                            if (success) {
                                const success2 = await deleteCardById(cardData._id);

                                if (success2) {
                                    navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
                                }
                            } else {
                                alert("אירעה שגיאה")
                            }
                        } catch (error) {
                            console.error("An error occurred:", error);
                            // Handle the error here
                        }
                    },
                },
            ],
            { cancelable: false }
        );
    };

    const handleEditKebab = () => {

        setIsKebabMenuVisible(false); // Close the menu

    };

    const handleShareKebab = () => {


        setIsKebabMenuVisible(false); // Close the menu

    };


    const renderKebabMenu = () => {
        return (
            <Modal
                transparent={true}
                visible={isKebabMenuVisible}
                onRequestClose={closeKebabMenu}
            >
                <View style={[styles.kebabMenuContainer, { justifyContent: 'center', alignItems: 'center' }]}>
                    <TouchableOpacity onPress={() => handleDeleteKebab()}>
                        <Text style={styles.kebabMenuItem}>Delete</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => {
                        handleEditKebab();
                        navigation.navigate('EditPost', { cardData });
                    }}>
                        <Text style={styles.kebabMenuItem}>Edit</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => handleShareKebab()}>
                        <Text style={styles.kebabMenuItem}>Share</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={closeKebabMenu}>
                        <Text style={styles.kebabMenuItem}>Close</Text>
                    </TouchableOpacity>
                </View>
            </Modal>
        );
    };

    return (
        <View style={styles.postContainer}>


            {cardData.owner.id === currentUser._id && (
                <TouchableOpacity
                    style={styles.kebabIcon}
                    onPress={toggleKebabMenu}
                >
                    <Image source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Kebab-menu-ui-icon-1.svg/2048px-Kebab-menu-ui-icon-1.svg.png' }} style={styles.kebabIconImage} />
                </TouchableOpacity>
            )}

            <View style={styles.headerContainer}>
                <Image
                    source={{ uri: cardData.owner.profileImage || 'https://upload.wikimedia.org/wikipedia/commons/b/bc/Unknown_person.jpg' }}
                    style={styles.avatar}
                />
                <Text style={styles.username}>{cardData.owner.name}</Text>
            </View>

            <Image
                source={{ uri: cardData.image }}
                style={[styles.postImage, { height: imageHeights[cardData.image] || screenWidth }]}
            />

            <View style={styles.actionsContainer}>
                <TouchableOpacity style={styles.actionButton} onPress={handleLike}>
                    <Image source={{ uri: 'https://cdn-icons-png.flaticon.com/512/126/126473.png' }} style={styles.actionIcon} />
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton} onPress={() => openCommentsModal(cardData.comments, cardData)}>
                    <Image source={{ uri: 'https://cdn2.iconfinder.com/data/icons/medical-healthcare-26/28/Chat-2-512.png' }} style={styles.actionIcon} />
                </TouchableOpacity>
            </View>

            <Text style={styles.likeText}>{`${likes} likes`}</Text>
            <View style={styles.commentContainer1}>
                <Text style={styles.usernameToComment}>{cardData.owner.name}</Text>
                <Text style={styles.imageBioToComment}>{cardData.imageBio}</Text>
            </View>
            <TouchableOpacity
                style={styles.actionButtonComment}
                onPress={() => openCommentsModal(cardData.comments, cardData)}
            >
                <Text style={styles.actionText}>See All Comments ({cardData.comments.length})</Text>
            </TouchableOpacity>
            <View>
                {/* Show the first three comments */}
                {cardData.comments !== undefined && cardData.comments.length > 0 && (
                    <View style={styles.commentContainer3}>
                        {cardData.comments.slice(0, 3).map((comment, commentIndex) => (
                            <View key={commentIndex} style={styles.commentContainer2}>
                                <Text style={styles.usernameToComment}>{comment.userName}</Text>
                                <Text style={styles.imageBioToComment}> {comment.comment}</Text>
                            </View>
                        ))}
                    </View>
                )}
            </View>
            <CommentModalToProfile
                comments={selectedCarComments}
                card={selectedCardId}
                onClose={closeCommentsModal}
                updateComments={updateComments} // Pass the update function
            />
            {isKebabMenuVisible && renderKebabMenu()}
        </View>
    );
};

const screenWidth = Dimensions.get('window').width;

const styles = StyleSheet.create({
    commentContainer3: {
        paddingTop: '2%',
    },
    commentContainer2: {
        flexDirection: 'row',
        paddingLeft: '3%',
    },
    commentContainer1: {
        flexDirection: 'row',
        paddingLeft: '2%',
    },
    actionText: {
        paddingLeft: '3%',
        paddingTop: '2%',
    },
    usernameToComment: {
        fontWeight: 'bold',
    },
    imageBioToComment: {
        paddingLeft: '1.5%',
    },
    postContainer: {
        marginVertical: 10,
        backgroundColor: '#fff',
        borderRadius: 10,
    },
    headerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
    },
    avatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
        marginRight: 10,
    },
    username: {
        fontSize: 16,
        fontWeight: 'bold',
    },
    postImage: {
        width: screenWidth,
        // The height is set dynamically using imageHeights state
    },
    actionsContainer: {
        flexDirection: 'row',
        padding: 10,
    },
    actionButton: {
        padding: 5,
    },
    actionIcon: {
        width: 24,
        height: 24,
    },
    likeText: {
        marginLeft: 10,
        marginBottom: 5,
        fontWeight: 'bold',
    },
    caption: {
        marginLeft: 10,
        marginBottom: 10,
    },
    kebabIcon: {
        position: 'absolute',
        top: 10,
        right: 10,
        zIndex: 1,
    },
    kebabIconImage: {
        width: 24,
        height: 24,
    },
    kebabMenuContainer: {
        position: 'absolute',
        top: 50,
        right: 10,
        backgroundColor: '#fff',
        borderRadius: 5,
        elevation: 5,
        padding: 10,
    },
    kebabMenuItem: {
        fontSize: 16,
        paddingVertical: 5,
    },
});

export default EachCardPost;
