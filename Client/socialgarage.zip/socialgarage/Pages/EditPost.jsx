import React, { useContext, useState, useEffect } from 'react';
import { View, Text, Image, TextInput, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';

const EditPost = ({ route }) => {
    const navigation = useNavigation();
    const { cardData } = route.params;
    const { currentUser, setCurrentUser } = useContext(UserContext);
    const [editedCaption, setEditedCaption] = useState(cardData.imageBio);

    const handleSave = async () => {
        try {

            const newImageBio = {
                imageBio: editedCaption,
                userId: currentUser._id,
                carNumber: cardData.carNumber,
            };


            const response = await fetch(`https://socialgarage.onrender.com/api/users/${cardData._id}/updateImageBio`, {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                },
                body: JSON.stringify({ newImageBio: newImageBio }),
            });

            if (response.status === 200) {
                const user = await response.json();
                setCurrentUser(user);

                try {
                    const newImageBio2 = {
                        imageBio: editedCaption,
                    };

                    const response2 = await fetch(`https://socialgarage.onrender.com/api/cards/${cardData._id}/updateImageBio`, {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json; charset=UTF-8',
                        },
                        body: JSON.stringify({ newImageBio: newImageBio2 }),
                    });


                    if (response2.status === 200) {
                        navigation.navigate('TabbedPageNavigator');

                    } else {
                        alert('משהו השתבש');
                    }
                } catch (error) {
                    console.error(error);
                    // Handle error
                }




            } else {
                alert('משהו השתבש');
            }
        } catch (error) {
            console.error(error);
            return false; // Error occurred
        }
    };

    return (
        <View style={styles.container}>
            <Image
                source={{ uri: cardData.image }}
                style={styles.postImage}
            />
            <TextInput
                style={styles.captionInput}
                placeholder="Edit caption..."
                onChangeText={text => setEditedCaption(text)}
                value={editedCaption}
            />
            <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
                <Text style={styles.saveButtonText}>Save</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    postImage: {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').width,
    },
    captionInput: {
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 5,
        padding: 10,
        marginTop: 20,
        width: Dimensions.get('window').width - 40,
    },
    saveButton: {
        backgroundColor: 'blue',
        padding: 10,
        borderRadius: 5,
        marginTop: 20,
    },
    saveButtonText: {
        color: 'white',
        textAlign: 'center',
    },
});

export default EditPost;