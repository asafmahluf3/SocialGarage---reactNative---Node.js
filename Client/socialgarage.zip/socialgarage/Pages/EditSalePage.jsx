import React, { useContext, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import { ActivityIndicator } from 'react-native-paper';

export default function SalePage({ route }) {
  const navigation = useNavigation();

  const { carData } = route.params;
  const [price, setPrice] = useState('');
  const [details, setDetails] = useState('');
  const { currentUser, updateSaleDetails, updateIsForSaleTrueInCard } = useContext(UserContext);
  const [remainingChars, setRemainingChars] = useState(300);
  const [isLoading, setIsLoading] = useState(false);

  const handleSaleCar = async () => {
    if (!price || !details) {
      alert('נא למלא את כל השדות');
      return;
    }

    setIsLoading(true);

    const carNumber = carData.carNumber;

    const success = await updateSaleDetails(carNumber, price, details);
    const successOfCard = await updateIsForSaleTrueInCard(carNumber);

    setIsLoading(false);

    if (success && successOfCard) {
      alert('הרכב הועלה למכירה בהצלחה');
      navigation.navigate('ProfilePage');
    } else {
      alert('בעיה זמנית, אנא נסה מאוחר יותר');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>מכירת רכב</Text>

      <Text style={styles.carDetails}>
        רכב: {carData.manufacturer} {carData.model}
      </Text>

      <TextInput
        style={styles.input1}
        placeholder="מחיר"
        value={carData.price}
        onChangeText={setPrice}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input2}
        placeholder="פרטים"
        value={carData.detailsOfSale}
        onChangeText={(text) => {
          if (text.length <= 300) {
            setDetails(text);
          }
        }}
        multiline
        numberOfLines={10}
        textAlignVertical="top"
        maxLength={300}
      />
      <Text style={styles.charCount}>
        {details ? `${details.length}/300` : '0/300'}
      </Text>



      {isLoading ? (
        <ActivityIndicator size="large" color="#ff5f04" style={styles.loadingIndicator} />
      ) : (
        <TouchableOpacity style={styles.editButton} onPress={handleSaleCar}>
          <Text style={styles.editButtonText}>עדכן</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  loadingIndicator: {
    marginTop: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  charCount: {
    textAlign: 'right',
    color: '#999',
    marginBottom: 10,
  },
  carDetails: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input1: {
    height: 40,
    borderWidth: 1,
    borderColor: '#ff5f04',
    borderRadius: 5,
    marginBottom: 15,
    padding: 10,
    textAlign: 'right',
    fontWeight: 'bold',
  },
  input2: {
    borderWidth: 1,
    borderColor: '#ff5f04',
    borderRadius: 5,
    padding: 10,
    textAlign: 'right',
    fontWeight: 'bold',
    paddingTop: 0,
    height: 150,
  },
  loremText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
    textAlign: 'center',
  },
  editButton: {
    alignSelf: 'center',
    backgroundColor: '#FF5F04', // Change background color to FF5F04
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20, // Change border radius to 20
    marginTop: 10,
  },
  editButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
