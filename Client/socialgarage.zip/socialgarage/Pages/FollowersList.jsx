import React, { useContext, useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';

const FollowersList = ({ route }) => {
  const { userId } = route.params;
  const { currentUser } = useContext(UserContext);
  const navigation = useNavigation();

  const [followersList, setFollowersList] = useState([]);

  useEffect(() => {
    // Fetch followers list based on userId
    fetchFollowersList();
  }, []);

  const fetchFollowersList = async () => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${userId}/followers`);
      if (!response.ok) {
        throw new Error(`Request failed with status: ${response.status}`);
      }
      const data = await response.json();
      setFollowersList(data);
    } catch (error) {
      console.error('Error fetching followers list:', error);
    }
  };

  const renderFollowerItem = ({ item }) => (
    <TouchableOpacity style={styles.followerItem} onPress={() => handleUserPress(item)}>
      <Image source={{ uri: item.profileImage }} style={styles.profileImage} />
      <View style={styles.followerInfo}>
        <Text style={styles.followerName}>{item.name}</Text>
      </View>
    </TouchableOpacity>
  );

  const handleUserPress = (item) => {
    if (currentUser._id === item._id) {
      navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
    } else {
      navigation.navigate('SocialUserPublicCars', { userId: item._id, userName: item.name, profileImage: item.profileImage });
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Followers List</Text>
      <FlatList
        data={followersList}
        keyExtractor={(item) => item._id}
        renderItem={renderFollowerItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#F5F5F5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  followerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    marginBottom: '2%',
  },
  followerInfo: {
    flex: 1,
  },
  followerName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  profileImage: {
    width: 40, // Adjust the width and height as needed
    height: 40, // to fit your design
    borderRadius: 20, // Half of the width and height to make it circular
    marginRight: 10, // Spacing between image and text
  },
});

export default FollowersList;
