import React from 'react';
import { View, Text, TouchableOpacity, Linking, ScrollView, StyleSheet, Alert } from 'react-native';
import { Icon, Card } from 'react-native-elements';

const EachGarageDetails = ({ route }) => {
    const { garage } = route.params;

    const handlePhoneNumberPress = () => {
        if (garage.phoneNumber) {
            Linking.openURL(`tel:${garage.phoneNumber}`);
        }
    };

    const handleNavigationPress = () => {
        const address = `${garage.city}, ${garage.address}`;

        // Define the navigation URLs for Google Maps and Waze
        const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;
        const wazeUrl = `https://waze.com/ul?q=${encodeURIComponent(address)}`;

        // Show an alert with navigation options
        Alert.alert(
            'Choose Navigation App',
            'Select a navigation app to open the address:',
            [
                {
                    text: 'Google Maps',
                    onPress: () => Linking.openURL(googleMapsUrl),
                },
                {
                    text: 'Waze',
                    onPress: () => Linking.openURL(wazeUrl),
                },
                {
                    text: 'Cancel',
                    style: 'cancel',
                },
            ],
            { cancelable: true }
        );
    };



    return (
        <ScrollView style={styles.container}>
            <View style={styles.cardContainer}>
                <Card containerStyle={styles.card}>
                    <Text style={styles.title}>
                        {garage.name}
                    </Text>

                    <Text style={styles.company}>
                        מורשה {garage.garageCompany}
                    </Text>


                    <View style={styles.infoContainer}>
                        <TouchableOpacity onPress={handleNavigationPress}>
                            <Text style={styles.info}>
                                {garage.city}, {garage.address}
                            </Text>
                        </TouchableOpacity>
                        <Icon name="location" type="entypo" style={styles.icon} />
                    </View>


                    {garage.phoneNumber && (
                        <TouchableOpacity onPress={handlePhoneNumberPress}>
                            <View style={styles.phoneNumberContainer}>
                                <Text style={styles.phoneNumber}>
                                    {garage.phoneNumber}
                                </Text>
                                <Icon name="phone" type="font-awesome" style={styles.icon} />
                            </View>
                        </TouchableOpacity>
                    )}

                    <Text style={styles.reviewTitle}>ביקורות:</Text>
                    {garage.reviews.map((review, index) => (
                        <Card key={index} containerStyle={styles.reviewCard}>
                            <Text style={styles.username}>
                                {review.username}
                            </Text>
                            <Text style={styles.reviewInfo}>ציון: {review.rank}</Text>
                            <Text style={styles.reviewInfo}>ביקורת: {review.review}</Text>
                            <Text style={styles.reviewInfo}>תאריך ביקור: {review['visit date']}</Text>
                            <Text style={styles.reviewInfo}>תשובת המוסך: {review['garage answer']}</Text>
                        </Card>
                    ))}
                </Card>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f5f5f5',
    },
    cardContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    card: {
        borderRadius: 10,
        backgroundColor: '#fff',
        flex: 1,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 10,
        color: '#333',
        textAlign: 'right',
    },
    infoContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        marginBottom: 10,
    },
    info: {
        flex: 1,
        color: '#555',
        textAlign: 'right',
    },
    icon: {
        color: '#555',
    },
    phoneNumberContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        marginBottom: 10,
    },
    phoneNumber: {
        flex: 1,
        color: '#007bff',
        textDecorationLine: 'underline',
        textAlign: 'right',
    },
    reviewTitle: {
        fontSize: 20,
        marginTop: 10,
        color: '#333',
        textAlign: 'right',
    },
    reviewCard: {
        borderRadius: 10,
        marginBottom: 10,
        backgroundColor: '#f9f9f9',
        textAlign: 'right',
    },
    username: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 5,
        color: '#555',
        textAlign: 'right',
    },
    reviewInfo: {
        color: '#777',
        textAlign: 'right',
    },
    company: {
        fontSize: 18, // You can adjust the font size as needed
        color: '#555',
        marginBottom: 5,
        textAlign: 'right',
    },
});

export default EachGarageDetails;
