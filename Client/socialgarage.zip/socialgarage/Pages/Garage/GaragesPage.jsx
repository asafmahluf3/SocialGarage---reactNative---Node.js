import React, { useContext, useState, useEffect } from 'react';
import { View, Text, StyleSheet, Platform, ScrollView, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import { GaragesContext } from '../../Contexts/GaragesContextProvider';
import * as Location from 'expo-location';
import { useNavigation } from '@react-navigation/native';

// Function to calculate the distance between two coordinates
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * (Math.PI / 180))) *
    Math.cos((lat2 * (Math.PI / 180))) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  return distance;
}

// Function to generate star ratings based on average rank
function renderStarRating(averageRank) {
  const totalStars = 5;
  const roundedRank = Math.round(averageRank);

  // Create an array to store the star components
  const stars = [];

  // Fill the stars array with filled or empty stars based on the average rank
  for (let i = 1; i <= totalStars; i++) {
    if (i <= roundedRank) {
      stars.push(
        <Image
          key={i}
          source={{
            uri: 'https://cdn.iconscout.com/icon/free/png-256/free-star-bookmark-favorite-shape-rank-16-28621.png',
          }}
          style={{ width: 20, height: 20 }}
        />
      );
    } else {
      stars.push(
        <Image
          key={i}
          source={{
            uri: 'https://cdn3.iconfinder.com/data/icons/stars-5/512/disabled_star-512.png',
          }}
          style={{ width: 20, height: 20 }}
        />
      );
    }
  }

  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
      {stars}
    </View>
  );
}


export default function GaragesPage({ route }) {
  const navigation = useNavigation();
  const { garages } = useContext(GaragesContext);
  const { carData } = route.params;

  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [userLongitude, setLongitude] = useState(null);
  const [userLatitude, setLatitude] = useState(null);
  const [isLoadingLocation, setLoadingLocation] = useState(true); // Track loading state

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        setLoadingLocation(false); // Set loading state to false
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
      setLongitude(location.coords.longitude);
      setLatitude(location.coords.latitude);
      setLoadingLocation(false); // Set loading state to false once location is obtained
    })();
  }, []);

  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  const hasMatchingGarages = garages.some(
    (garage) => carData.manufacturer === garage.garageCompany
  );

  if (!hasMatchingGarages) {
    return (
      <View style={styles.container}>
        <Text style={styles.noMatchingGaragesText}>
          אין מוסכים התואמים לרכב שלך
        </Text>
      </View>
    );
  }
  // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  function calculateAverageRank(reviews) {
    if (reviews.length === 0) return 0;

    const totalRank = reviews.reduce((sum, review) => sum + review.rank, 0);
    return totalRank / reviews.length;
  }


  const formatDistance = (distance) => {
    return `${distance.toFixed(2)} ק"מ`;
  };

  // Display loading indicator while waiting for location
  if (isLoadingLocation) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#ff5f04" />
        <Text>Loading...</Text>
      </View>
    );
  }

  // Calculate the average rank for each garage
  const filteredAndSortedGarages = garages
    .filter((garage) => carData.manufacturer === garage.garageCompany)
    .map((garage) => ({
      ...garage,
      distance: calculateDistance(
        userLatitude,
        userLongitude,
        garage.latitude,
        garage.longitude
      ),
      averageRank: calculateAverageRank(garage.reviews), // Add averageRank property
    })).sort((a, b) => a.distance - b.distance);





    return (
      <ScrollView style={styles.container}>
        <View style={styles.pageTitleContainer}>
          <Text style={styles.pageTitle}>מוסכים מורשים {carData.manufacturer}</Text>
        </View>
        {filteredAndSortedGarages.map((garage) => (
          <View key={garage._id} style={styles.garageContainer}>
            <TouchableOpacity
              style={styles.garageItem}
              onPress={() =>
                navigation.navigate('EachGarageDetails', { garage })
              }
            >
              <Image
                source={{
                  uri:
                    garage.image ||
                    'https://static.thenounproject.com/png/1554489-200.png',
                }}
                style={styles.garageImage}
              />
              <View style={styles.garageDetails}>
                <Text style={[styles.garageName, { textAlign: 'right' }]}>
                  {garage.name}
                </Text>
                <Text style={[styles.garageCity, { textAlign: 'right' }]}>
                  {garage.city}
                </Text>
                <Text style={[styles.garageAddress, { textAlign: 'right' }]}>
                  {garage.address}
                </Text>
                <Text style={{ textAlign: 'right' }}>
                  {formatDistance(garage.distance)}
                </Text>
                <Text>{renderStarRating(garage.averageRank)}</Text>
              </View>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    );
    
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f8f8f8', // Background color
  },
  pageTitleContainer: {
    alignItems: 'center', // Center the title horizontally
  },
  pageTitle: {
    fontSize: 24, // Adjust the font size as needed
    fontWeight: 'bold', // Make the title bold
    textAlign: 'center', // Center the title text
  },
  garageContainer: {
    width: '90%',
    alignSelf: 'center',
    borderColor: '#ddd', // Border color
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f1ead0', // Background color for each garage item
    shadowColor: '#000', // Box shadow color (for iOS)
    shadowOffset: { width: 0, height: 2 }, // Box shadow offset (for iOS)
    shadowOpacity: 0.1, // Box shadow opacity (for iOS)
    shadowRadius: 2, // Box shadow radius (for iOS)
    elevation: 2, // Box shadow elevation (for Android)
  },
  garageItem: {
    borderRadius: 8,
    padding: 16,
    flex: 1,
    flexDirection: 'row',
  },
  garageImage: {
    width: 70,
    height: 70,
    borderRadius: 100,
    marginRight: 10,
    alignSelf: 'center',
  },
  garageDetails: {
    flex: 1,
  },
  garageName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333', // Text color
  },
  garageCity: {
    fontSize: 14,
    color: '#666', // Text color
  },
  garageAddress: {
    fontSize: 14,
    color: '#666', // Text color
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
