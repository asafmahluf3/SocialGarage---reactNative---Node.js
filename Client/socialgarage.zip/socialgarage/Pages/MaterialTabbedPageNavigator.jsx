import React from 'react';
import { Text } from 'react-native';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { FontAwesome } from 'react-native-vector-icons';

import ProfilePage from './ProfilePage';
import BulbsCar from './BulbsCar';
import SocialFeedPage from './SocialFeedPage';
import SearchPage from './SearchPage';
import CarsBeforeGarages from './Garage/CarsBeforeGarages';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faLightbulb, faSearch, faCar, faWarehouse, faUser } from '@fortawesome/free-solid-svg-icons';



const Tab = createMaterialBottomTabNavigator();

export default function MaterialTabbedPageNavigator() {
    return (
        <Tab.Navigator
            initialRouteName="SocialFeed"
            activeColor="#55ff00"
            inactiveColor="black"
            barStyle={{ backgroundColor: '#FFF', height: "10%",  borderWidth: 1, borderColor: '#dcdcdc' }}

        >




            <Tab.Screen
                name="Bulbs Car"
                component={BulbsCar}
                options={{
                    tabBarLabel: (
                        <Text style={{ fontSize: 12, fontWeight: '700', color: 'black' }}>
                            נורות
                        </Text>
                    ),
                    tabBarIcon: ({ color }) => (
                        <FontAwesomeIcon icon={faLightbulb} color={"black"} size={25} />
                    ),

                }}
            />


            <Tab.Screen
                name="Search"
                component={SearchPage}
                options={{
                    tabBarLabel: (
                        <Text style={{ fontSize: 12, fontWeight: '700', color: 'black' }}>
                            חיפוש
                        </Text>
                    ),
                    tabBarIcon: ({ color }) => (
                        <FontAwesomeIcon icon={faSearch} color={"black"} size={25} />
                    ),
                }}
            />



            <Tab.Screen
                name="SocialFeed"
                component={SocialFeedPage}
                options={{
                    tabBarLabel: (
                        <Text style={{ fontSize: 12, fontWeight: '700', color: 'black' }}>
                            פיד חברתי
                        </Text>
                    ),
                    tabBarIcon: ({ color }) => (
                        <FontAwesomeIcon icon={faCar} color={"black"} size={25} />
                    ),
                }}
            />


            <Tab.Screen
                name="carsBeforeGarages"
                component={CarsBeforeGarages}
                options={{
                    tabBarLabel: (
                        <Text style={{ fontSize: 12, fontWeight: '700', color: 'black' }}>
                            מוסכים
                        </Text>
                    ),
                    tabBarIcon: ({ color }) => (
                        <FontAwesomeIcon icon={faWarehouse} color={"black"} size={25} />
                    ),
                }}
            />



            <Tab.Screen
                name="Profile"
                component={ProfilePage}
                options={{
                    tabBarLabel: (
                        <Text style={{ fontSize: 12, fontWeight: '700', color: 'black' }}>
                            פרופיל
                        </Text>
                    ),
                    tabBarIcon: ({ color }) => (
                        <FontAwesomeIcon icon={faUser} color={"black"} size={25} />
                    ),
                }}
            />






        </Tab.Navigator>
    );
}
