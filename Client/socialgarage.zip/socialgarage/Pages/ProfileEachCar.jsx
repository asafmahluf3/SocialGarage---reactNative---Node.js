import React, { useState, useContext, useEffect, useRef } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Alert, Platform, Dimensions } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import cheerio from 'cheerio';
import { useNavigation } from '@react-navigation/native';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { ActivityIndicator } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LottieView from 'lottie-react-native';
import * as ImagePicker from 'expo-image-picker';


Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: false,
        shouldSetBadge: false,
    }),
});

async function sendPushNotification(expoPushToken, updatedKilometers) {
    const message = {
        to: expoPushToken,
        sound: 'default',
        title: 'Car Mileage Update',
        body: `Your car's mileage has been updated to ${updatedKilometers} km!`,
        data: { someData: 'goes here' },
    };

    await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
            Accept: 'application/json',
            'Accept-encoding': 'gzip, deflate',
            'Content-Type': 'application/json',
            'Accept': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify(message),
    });
}

async function registerForPushNotificationsAsync() {
    let token;
    if (Device.isDevice) {
        const { status: existingStatus } = await Notifications.getPermissionsAsync();
        let finalStatus = existingStatus;
        if (existingStatus !== 'granted') {
            const { status } = await Notifications.requestPermissionsAsync();
            finalStatus = status;
        }
        if (finalStatus !== 'granted') {
            alert('Failed to get push token for push notification!');
            return;
        }
        token = (await Notifications.getExpoPushTokenAsync()).data;
        console.log(token);
    } else {
        alert('Must use physical device for Push Notifications');
    }

    if (Platform.OS === 'android') {
        Notifications.setNotificationChannelAsync('default', {
            name: 'default',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
        });
    }
    return token;
}


export default function ProfileEachCar({ route }) {
    const navigation = useNavigation();
    const { carData } = route.params;
    const { updateIsForSaleFalseInCard, updateCarMileage, updateCarTest, deleteCar, transferCar, transferCarNumberInCard, currentUser, SendMail, addNewCard, allCars, removeSaleDetailsFromCar, updateImageCar } = useContext(UserContext);
    const [mileageState, setMileage] = useState(carData.currentMileage);
    const [testValidity, setTestValidity] = useState(carData.testValidity);
    const [web, setWeb] = useState(`https://data.gov.il/api/3/action/datastore_search?resource_id=053cea08-09bc-40ec-8f7a-156f0677aff3&q={"mispar_rechev":"${carData.carNumber}"}`);

    const [newOwnerEmail, setNewOwnerEmail] = useState('');
    const [newOwnerId, setNewOwnerId] = useState('');
    const [newOwnerName, setNewOwnerName] = useState('');
    const [isUploading, setIsUploading] = useState(false);



    const [expoPushToken, setExpoPushToken] = useState('');
    const [notification, setNotification] = useState(false);
    const notificationListener = useRef();
    const responseListener = useRef();


    const [removeSaleLoading, setRemoveSaleLoading] = useState(false);


    useEffect(() => {
        registerForPushNotificationsAsync().then(token => setExpoPushToken(token));

        notificationListener.current = Notifications.addNotificationReceivedListener(notification => {
            setNotification(notification);
        });

        responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
            console.log(response);
        });

        return () => {
            Notifications.removeNotificationSubscription(notificationListener.current);
            Notifications.removeNotificationSubscription(responseListener.current);
        };
    }, []);


    const updateMileage = () => {
        Alert.prompt('עדכון ק"מ', 'הכנס ק"מ מעודכן:', async (newMileage) => {
            const mileage = parseInt(newMileage);

            if (!isNaN(mileage)) {
                if (mileage >= carData.currentMileage) {
                    // Update the mileage state and send push notification
                    updateCarMileage(carData.carNumber, mileage);
                    setMileage(mileage);
                    carData.currentMileage = mileage;

                    sendPushNotification(expoPushToken, mileage);

                } else {
                    Alert.alert('ק"מ לא תקין', 'אנא הכנס ק"מ גדול מקודמו');
                }
            } else {
                Alert.alert('ק"מ לא תקין', 'אנא הכנס ספרות בלבד');
            }
        });
    };




    const updateTest = async () => {
        try {
            // שליחת הבקשה וקבלת התשובה
            const response = await fetch(web);
            const data = await response.json();
            const records = data.result.records[0];

            if (records) {
                const testFetch = formatDate(records.tokef_dt);
                if (testFetch === testValidity) {
                    alert("לא התעדכן, במקרה ועשית טסט לוקח שבועיים להתעדכן")
                } else if (testFetch === null || testFetch === undefined || testFetch === '') {
                    alert("יש בעיה כלשהי? צור איתנו קשר")
                } else {
                    setTestValidity(testFetch);
                    updateCarTest(carData.carNumber, testFetch);
                    alert("טסט התעדכן בהצלחה");
                }
            } else {
                alert('לא נמצא מידע עבור המספר רכב');
            }
        } catch (error) {
            console.error(error);
        }
    };





    const formatDate = (inputDate) => {
        const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
        const dateParts = inputDate.split('-');
        const formattedDate = new Date(`${dateParts[0]}-${dateParts[1]}-${dateParts[2]}`).toLocaleDateString('he-IL', options);
        return formattedDate.replace(/\./g, '/'); // החלף את הנקודות בפסיקים
    };







    const deleteCarConfirmation = async () => {
        try {
            Alert.alert(
                'מחיקת רכב',
                'האם אתה בטוח שברצונך למחוק את הרכב?',
                [
                    { text: 'ביטול', style: 'cancel' },
                    { text: 'מחק', onPress: () => deleteCarAndSendEmail() }
                ]
            );
        } catch (error) {
            console.error(error);
        }
    };

    const deleteCarAndSendEmail = async () => {
        try {
            const success = await deleteCar('admin@gmail.com', carData.carNumber);

            if (success) {
                alert('המחיקה התבצעה בהצלחה');
                navigation.navigate('ProfilePage');
            } else {
                alert('רכב לא נמחק');
            }
        } catch (error) {
            console.error(error);
            alert('אירעה שגיאה במחיקת הרכב');
        }
    };



    const transferCarConfirmation = async () => {
        try {
            const newOwnerEmail = await new Promise((resolve) => {
                Alert.prompt('העברת רכב', 'הזן את האימייל של המשתמש החדש:', (email) => {
                    resolve(email);
                });
            });

            setNewOwnerEmail(newOwnerEmail);


            const originalKey = await SendMail(newOwnerEmail);

            const enteredKey = await new Promise((resolve) => {
                const handlePrompt = (key) => {
                    resolve(key);
                };
                Alert.prompt('הזן את המפתח שנשלח למייל שהזנת לצורך השלמת העברת רכב', 'ברגעים אלו נשלח מפתח למייל שהוזן', handlePrompt);
            });

            if (enteredKey === originalKey) {









                const transferSuccess = transferCar(newOwnerEmail, carData.carNumber);
                if (transferSuccess) {

                    const response = await fetch(`https://socialgarage.onrender.com/api/users/getUserIdAndNameByEmail/${newOwnerEmail}`);

                    const data = await response.json();


                    const transferSuccess2 = transferCarNumberInCard(carData.carNumber, data._id, data.name, data.profileImage);
                    if (transferSuccess2) {
                        alert('הועבר בהצלחה');
                        navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
                    }

                } else {
                    alert('רכב לא הועבר');
                }
            }
            else {
                alert('המפתח שהוזן אינו תקין');
            }
        } catch (error) {
            console.error(error);
        }
    };


    const Tahzuka = () => {
        navigation.navigate('TahzukaCar', { carData });
    };

    const navigateToProfileEachCarSocial = () => {
        navigation.navigate('ProfileEachCarSocial', { carData });
    };

    const navigateToSalePage = () => {
        navigation.navigate('SalePage', { carData });
    };

    const removeFromSale = async () => {
        try {
            Alert.alert(
                'הורדת המכירה',
                'האם אתה בטוח שברצונך להסיר את הרכב מהמכירה?',
                [
                    { text: 'ביטול', style: 'cancel' },
                    { text: 'הסר ממכירה', onPress: confirmRemoveFromSale }
                ]
            );
        } catch (error) {
            console.error(error);
        }
    };

    const confirmRemoveFromSale = async () => {
        try {
            setRemoveSaleLoading(true); // Start loading

            const success = await removeSaleDetailsFromCar(carData.carNumber);
            const successOfCard = await updateIsForSaleFalseInCard(carData.carNumber);

            setRemoveSaleLoading(false); // Stop loading

            if (success && successOfCard) {
                alert('הורדת המכירה התבצעה בהצלחה');
                navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });

            } else {
                alert('לא ניתן להסיר את הרכב מהמכירה');
            }
        } catch (error) {
            console.error(error);
            alert('אירעה שגיאה בהורדת הרכב מהמכירה');
        }
    };






    const openImagePickerAsync = async () => {
        if (Platform.OS !== 'web') {
            const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (permissionResult.granted === false) {
                alert('נא לאשר גישה לגלריה ולמצלמה');
                return;
            }
        }

        Alert.alert(
            'בחר מקור תמונה',
            'בחר מקור לתמונה',
            [
                {
                    text: 'מצלמה',
                    onPress: () => launchCamera(),
                },
                {
                    text: 'גלריה',
                    onPress: () => launchGallery(),
                },
                {
                    text: 'ביטול',
                    style: 'cancel',
                },
            ],
            { cancelable: true }
        );
    };




    const launchCamera = async () => {
        let permissionResult = await ImagePicker.requestCameraPermissionsAsync();

        if (permissionResult.granted === false) {
            alert("נדרשת הרשאה לגשת למצלמה!");
            return;
        }

        let pickerResult = await ImagePicker.launchCameraAsync({ base64: true, quality: 1.0 });

        if (!pickerResult.canceled) {
            await ImageUploader(pickerResult.assets[0].base64);
        }
    };





    //ask for permisstion
    const launchGallery = async () => {
        let permissionResult =
            await ImagePicker.requestMediaLibraryPermissionsAsync();

        if (permissionResult.granted === false) {
            alert("נדרשת הרשאה לגשת לגלריה!");
            return;
        }

        let pickerResult = await ImagePicker.launchImageLibraryAsync({ base64: true, quality: 1.0 });

        if (!pickerResult.canceled) {
            await ImageUploader(pickerResult.assets[0].base64);
        }
    };


    const ImageUploader = async (uri) => {
        try {
            setIsUploading(true); // Set isUploading to true while the image is being uploaded

            const response = await fetch(`https://socialgarage.onrender.com/api/users/upload`, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ image: uri }),
            });

            const data = await response.json();


            if (!response.ok) {
                throw new Error("Failed to upload image");
            } else {
                await updateImageCar(carData.carNumber, data);
                carData.image = data;
            }

            return;
        } catch (err) {
            console.log(err);
        } finally {
            setIsUploading(false); // Ensure isUploading is set back to false even if an error occurs
        }
    };










    return (
        <View style={styles.container}>
            <View style={styles.coteret}>
                <Image style={styles.carImage} source={{ uri: carData.image }} />
                <Text style={styles.carName}> {carData.manufacturer}</Text>
                <Text style={styles.carName}> {carData.model}</Text>
                {carData.nickname && <Text style={styles.carName}> {"("}{carData.nickname}{")"}</Text>}
            </View>

            <View style={styles.row}>

                <TouchableOpacity style={styles.buttonNotCurrent} onPress={navigateToProfileEachCarSocial}>
                    <Text style={styles.buttonText}>פרופיל</Text>
                </TouchableOpacity>



                <TouchableOpacity style={styles.button}>
                    <Text style={styles.buttonText}>איזור אישי</Text>
                </TouchableOpacity>



            </View>

            <View style={styles.hr} />





            {isUploading ? (
                <View style={[styles.loadingContainer, styles.centeredContainer]}>
                    <View style={styles.centeredContainer}>
                        <LottieView
                            source={require('../lottieanimations/theAddphotoLoad.json')} // Replace with the path to your Lottie JSON file
                            autoPlay
                            loop
                            style={{ width: 100, height: 100, marginRight: 20 }} // Adjust the size and margin as needed
                        />
                        <Text style={[styles.loadingText]}>מעלה תמונה, אנא המתן...</Text>
                    </View>
                </View>
            ) : (
                <TouchableOpacity onPress={openImagePickerAsync}>
                    <Image style={styles.biggerCarImage} source={{ uri: carData.image }} />
                </TouchableOpacity>
            )}




            <View style={styles.theTwo}>
                {/* עדכון ק"מ */}
                <View style={styles.row1}>
                    <TouchableOpacity style={styles.button1} onPress={updateMileage}>
                        <Text style={styles.buttonText}>עדכן ק"מ</Text>
                    </TouchableOpacity>
                    <Text style={[styles.carDetails1, styles.luxuryText1, styles.kmShow1]}>{mileageState} ק"מ</Text>
                </View>
                <View style={styles.hr} />
                {/* סוף עדכון ק"מ */}



                {/* עדכון טסט */}
                <View style={styles.row}>
                    <TouchableOpacity style={styles.button1} onPress={updateTest}>
                        <Text style={styles.buttonText1}>עדכן טסט</Text>
                    </TouchableOpacity>
                    <Text style={[styles.carDetails1, styles.luxuryText1, styles.kmShow1]}>תוקף טסט: {testValidity}</Text>
                </View>
                <View style={styles.hr} />
                {/* סוף עדכון טסט */}
            </View>

            <Text style={[styles.carDetails, styles.luxuryText]}>מספר רכב: {carData.carNumber}</Text>
            <Text style={[styles.carDetails, styles.luxuryText]}>שנה: {carData.year}</Text>
            <Text style={[styles.carDetails, styles.luxuryText]}>יד: {carData.hand}</Text>
            <View style={styles.hr} />
            <View style={styles.buttonRow}>
                <TouchableOpacity style={[styles.button, styles.buttonLeft]} onPress={Tahzuka}>
                    <Text style={styles.buttonText}>תחזוקה</Text>
                </TouchableOpacity>

                {carData.isForSale ? (
                    removeSaleLoading ? (
                        <ActivityIndicator size="small" color="black" style={[styles.button, styles.buttonRight]} />
                    ) : (
                        <TouchableOpacity style={[styles.button, styles.buttonRight]} onPress={removeFromSale}>
                            <Text style={styles.buttonText}>הורד ממכירה</Text>
                        </TouchableOpacity>
                    )
                ) : (
                    <TouchableOpacity style={[styles.button, styles.buttonRight]} onPress={navigateToSalePage}>
                        <Text style={styles.buttonText}>תמכור אותי</Text>
                    </TouchableOpacity>
                )}
            </View>

            <View style={styles.buttonRow}>
                <TouchableOpacity style={[styles.button, styles.buttonLeft]} onPress={deleteCarConfirmation}>
                    <Text style={styles.buttonText}>מחק רכב</Text>
                </TouchableOpacity>

                <TouchableOpacity style={[styles.button, styles.buttonRight]} onPress={transferCarConfirmation}>
                    <Text style={styles.buttonText}>העבר רכב</Text>
                </TouchableOpacity>
            </View>









        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        alignItems: 'center',
        marginVertical: 10,
        padding: 20,
        elevation: 5,
    },
    loadingIndicator: {
        backgroundColor: 'transparent', // Remove background color to make it look like part of the button
        padding: 10, // Add padding for spacing
        margin: 10, // Use the same margin as the button for alignment
    },
    buttonText1: {
        color: 'black',
        fontWeight: 'bold',
    },
    kmShow1: {
        paddingLeft: 30,
    },
    luxuryText1: {
        fontWeight: 'bold',
        color: '#222',
    },
    button1: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        width: '40%',
        alignItems: 'center',
    },
    row1: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    carDetails1: {
        fontSize: 16,
        marginTop: 5,
        color: '#555',
    },
    coteret: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        textAlign: "center",
        marginBottom: 10,

    },
    carImage: {
        width: 60,
        height: 60,
        borderRadius: 50,
        marginRight: 10,
    },
    carName: {
        fontSize: '25%',
        fontWeight: 'bold',
        color: '#333',
    },

    carDetails: {
        fontSize: 16,
        marginTop: 5,
        color: '#555',
    },
    hr: {
        borderBottomWidth: 1,
        borderBottomColor: '#aaa',
        marginVertical: 10,
        width: "100%",
    },
    biggerCarImage: {
        width: Dimensions.get('window').width * 0.8, // Set 70% of the window width
        height: Dimensions.get('window').width * 0.5, // Set 70% of the window width to maintain a square shape
        resizeMode: 'cover', // Use 'cover' to make the image fill the square without stretching
        marginBottom: 10,
    },
    luxuryText: {
        fontWeight: 'bold',
        color: '#222',
    },
    buttonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
    },
    button: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        width: '49%',
        alignItems: 'center',
    },
    buttonLeft: {
        marginRight: '1%',
    },
    buttonRight: {
        marginLeft: '1%',
    },
    deleteButton: {
        backgroundColor: '#dc3545',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
        width: '80%',
        alignItems: 'center',
    },
    transferButton: {
        backgroundColor: '#28a745',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
        width: '80%',
        alignItems: 'center',
    },
    tahzukaButton: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
        width: '80%',
        alignItems: 'center',
    },
    buttonText: {
        color: 'black',
        fontWeight: 'bold',
    },
    row: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    kmShow: {
        paddingLeft: 30,
    },
    theTwo: {
        width: '100%',
    },
    modalContainer: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    closeButton: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
    },
    closeButtonText: {
        color: 'black',
        fontWeight: 'bold',
    },
    enlargedCarImage: {
        width: 350,
        height: 350,
        resizeMode: 'contain',
    },
    uploadButton: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        marginTop: 10,
        width: '80%',
        alignItems: 'center',
    },
    buttonNotCurrent: {
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 10,
        width: '40%',
        alignItems: 'center',
    },
    centeredContainer: {
        marginTop: '28%',
        marginBottom: '15%',
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
    },
    loadingText: {
        fontSize: 14,
        marginTop: 5,
        textAlign: 'center',
    },

});
