import React, { useState, useContext, useEffect, useRef } from 'react';
import {
    View,
    Text,
    Image,
    StyleSheet,
    TouchableOpacity,
    Alert,
    Modal,
    Platform,
    ActivityIndicator,
    Switch,
} from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import cheerio from 'cheerio';
import { useNavigation } from '@react-navigation/native';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { ScrollView } from 'react-native-gesture-handler';
import { Dimensions } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { AntDesign } from '@expo/vector-icons'; // Import the kebab menu icon

export default function ProfileEachCarSocialGuest({ route }) {
    const navigation = useNavigation();
    const { carData, userId, userName, profileImage } = route.params;
    const { currentUser, addNewCard, changeToPrivate, changeToPublic, deleteCardsByCarNumber, uploadTheLastAfterPublic } = useContext(UserContext);
    const [modalVisible, setModalVisible] = useState(false);
    const [image, setImage] = useState(null);
    const [loading, setLoading] = useState(false); // Add loading state
    const [isPrivate, setIsPrivate] = useState(carData.isPrivate);
    const [totalLikes, setTotalLikes] = useState(0); // State for total likes

    useEffect(() => {
        // Fetch the total likes for the car
        fetchTotalLikes(carData.carNumber);
    }, []);

    const fetchTotalLikes = async (carNumber) => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/total-likes/${carNumber}`);
            const data = await response.json();
            setTotalLikes(data.totalLikes);
        } catch (error) {
            console.error('Error fetching total likes:', error);
        }
    };

    const windowWidth = Dimensions.get('window').width;

    const handleImagePress = (card) => {
        navigation.navigate('EachCardPost', { cardData: card, carData: carData }); // Adjust the screen name and parameters as needed
    };

    return (
        <ScrollView>
            <View style={styles.container}>
                <TouchableOpacity style={styles.profileHeader}
                    onPress={() => navigation.navigate('SocialUserPublicCars', { userId: userId, userName: userName, profileImage: profileImage })}
                >
                    <Image style={styles.profileImage} source={{ uri: profileImage }} />
                    <Text style={styles.userName}>{userName}</Text>
                </TouchableOpacity>

                <View style={styles.hr} />



                <View style={styles.carInfo}>
                    <Image style={styles.carImage} source={{ uri: carData.image }} />
                    <Text style={styles.carName}> {carData.manufacturer}</Text>
                    <Text style={styles.carName}> {carData.model} </Text>
                    {carData.nickname && <Text style={styles.carName}>{"("}{carData.nickname}{")"}</Text>}
                </View>


                <Text style={styles.totalLikesText}>Total Likes: {totalLikes}</Text>

                <Image style={styles.biggerCarImage} source={{ uri: carData.image }} />

                {carData.isForSale && (
                    <TouchableOpacity
                        style={styles.button}
                        onPress={() => navigation.navigate('SalePageDetailsPage', { carData })}
                    >
                        <Text style={styles.buttonText}>צפה בדף מכירה</Text>
                    </TouchableOpacity>
                )}

                <View style={styles.rowImagesContainer}>
                    {/* Divide the cards into rows with 3 images per row */}
                    {carData.cards.slice().reverse().reduce((rows, card, index) => {
                        if (index % 3 === 0) {
                            rows.push([]);
                        }
                        rows[rows.length - 1].push(card);
                        return rows;
                    }, []).map((row, rowIndex) => (
                        <View key={rowIndex} style={styles.rowImages}>
                            {row.map((card, cardIndex) => (
                                <TouchableOpacity
                                    key={cardIndex}
                                    style={styles.imageInRow}
                                    onPress={() => handleImagePress(card)}
                                >
                                    <Image
                                        style={styles.imageInRowa}
                                        source={{ uri: card.image }}
                                    />
                                </TouchableOpacity>
                            ))}
                        </View>
                    ))}
                </View>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'column',
        alignItems: 'center',
        marginVertical: 10,
        padding: 20,
        elevation: 5,
    },
    profileHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
    },
    profileImage: {
        width: 80,
        height: 80,
        borderRadius: 40,
        marginRight: 10,
    },
    userName: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    carInfo: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        textAlign: "center",
        marginBottom: 10,
    },
    totalLikesText: {
        fontSize: 20,
        fontWeight: 'bold',
        marginTop: 10,
        marginBottom: 10,
        color: '#333',
    },
    carImage: {
        width: 60,
        height: 60,
        borderRadius: 50,
        marginRight: 10,
    },
    carName: {
        fontSize: '25%',
        fontWeight: 'bold',
        color: '#333',
    },
    hr: {
        borderBottomWidth: 1,
        borderBottomColor: '#aaa',
        marginVertical: 10,
        width: "100%",
    },
    biggerCarImage: {
        width: Dimensions.get('window').width * 0.7,
        height: Dimensions.get('window').width * 0.5,
        resizeMode: 'cover',
        marginBottom: 10,
    },
    button: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        width: '40%',
        alignItems: 'center',
        marginBottom: 10,
    },
    rowImagesContainer: {
        flexDirection: 'column',
        alignItems: 'center',
        width: '90%',
    },
    rowImages: {
        flexDirection: 'row',
        justifyContent: 'center',
        width: '100%',
    },
    imageInRow: {
        width: '40%',
        aspectRatio: 1,
        resizeMode: 'cover',
        margin: 2,
    },
    imageInRowa: {
        width: '100%',
        aspectRatio: 1,
    },
});
