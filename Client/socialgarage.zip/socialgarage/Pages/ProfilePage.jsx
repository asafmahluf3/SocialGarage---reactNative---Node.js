import React, { useContext, useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { UserContext } from '../Contexts/UserContextProvider';

export default function ProfilePage() {
  const navigation = useNavigation();
  const { currentUser } = useContext(UserContext);
  let [followersCount, setFollowersCount] = useState(currentUser.followers.length); // New state
  let [followingCount, setFollowingCount] = useState(currentUser.following.length); // New state
  let [totalLikes, setTotalLikes] = useState(0); // New state for total likes
  const [isRefreshing, setIsRefreshing] = useState(false);




  // ברגע של התנתקות יאפס את ה AsyncStorage
  const handleLogout = async () => {
    // Clear user credentials in AsyncStorage
    await AsyncStorage.removeItem('userEmail');
    await AsyncStorage.removeItem('userPassword');

    // Navigate to the login page
    navigation.reset({
      index: 0,
      routes: [{ name: 'WelcomePage' }],
    });
  };




  const navigateToProfileEachCar = (car) => {
    navigation.navigate('ProfileEachCarSocial', { carData: car });
  };


  const navigateToFollowersList = () => {
    navigation.navigate('FollowersList', { userId: currentUser._id });
  };

  const navigateToFollowingList = () => {
    navigation.navigate('FollowingList', { userId: currentUser._id });
  };


  useEffect(() => {
    fetchFollowersCount();
    fetchFollowingCount();
    fetchTotalLikes(); // Fetch total likes on component mount
  }, []);



  /************************************************כמות עוקבים ולייקים**********************************************************/
  const fetchFollowersCount = async () => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/followers/count`);
      if (!response.ok) {
        throw new Error(`Request failed with status: ${response.status}`);
      }
      const data = await response.json();
      setFollowersCount(data.count);
    } catch (error) {
      console.error('Error fetching followers count:', error);
    }
  };

  // Fetch user's following count
  const fetchFollowingCount = async () => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/following/count`);
      if (!response.ok) {
        throw new Error(`Request failed with status: ${response.status}`);
      }
      const data = await response.json();
      setFollowingCount(data.count);
    } catch (error) {
      console.error('Error fetching following count:', error);
    }
  };


  const fetchTotalLikes = async () => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/sum-likes`);
      if (!response.ok) {
        throw new Error(`Request failed with status: ${response.status}`);
      }
      const data = await response.json();
      setTotalLikes(data.totalLikes);
    } catch (error) {
      console.error('Error fetching total likes:', error);
    }
  };

  /**********************************************************************************************************************/



  const handleRefresh = async () => {
    try {
      await fetchFollowersCount()
      await fetchFollowingCount(); // Refresh the total likes
      await fetchTotalLikes(); // Fetch the card data here
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsRefreshing(false);
    }
  };



  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={isRefreshing}
          onRefresh={handleRefresh}
        />
      }
    >


      <View style={styles.container}>

        <Text style={styles.name}>{currentUser ? currentUser.name : ''}</Text>

        <View style={styles.container}>
          <View style={styles.userInfoContainer}>
            {/* Profile Image */}
            <Image
              source={{
                uri:
                  currentUser.profileImage ||
                  'https://upload.wikimedia.org/wikipedia/commons/b/bc/Unknown_person.jpg',
              }}
              style={styles.avatar}
            />

            {/* Space */}
            <View style={{ width: 20 }} />

            {/* Followers Count */}
            <TouchableOpacity style={styles.followContainer1} onPress={navigateToFollowersList}>
              <Text style={styles.followCount}>{followersCount}</Text>
              <Text style={styles.followLabel}>עוקבים</Text>
            </TouchableOpacity>

            {/* Space */}
            <View style={{ width: 20 }} />

            {/* Following Count */}
            <TouchableOpacity style={styles.followContainer} onPress={navigateToFollowingList}>
              <Text style={styles.followCount}>{followingCount}</Text>
              <Text style={styles.followLabel}>במעקב</Text>
            </TouchableOpacity>
          </View>

        </View>





        <Text style={styles.totalLikes}>לייקים :{totalLikes}</Text>


        <Text style={styles.sectionHeading}>הרכבים שלך: </Text>

        {currentUser && currentUser.cars && currentUser.cars.length > 0 ? (
          currentUser.cars.map((car, index) => (
            <TouchableOpacity
              key={index}
              style={styles.carContainer}
              onPress={() => navigateToProfileEachCar(car)}
            >
              <Image style={styles.carImage} source={{ uri: car.image }} />

              <Text style={styles.carName}>{car.manufacturer} {car.model}{car.nickname ? ` (${car.nickname})` : ''}</Text>
            </TouchableOpacity>
          ))
        ) : (
          <Text style={styles.noCarsText}>No cars available</Text>
        )}




        <TouchableOpacity
          style={styles.addCarButton}
          onPress={() => navigation.navigate('AddCar')}
        >
          <Text style={styles.addCarButtonText}>הוספת רכב</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.logoutButton, styles.logoutButtonAbsolute]} // הוסף סגנון ה-logoutButtonAbsolute
          onPress={handleLogout}
        >
          <Text style={styles.logoutButtonText}>התנתקות</Text>
        </TouchableOpacity>


      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  totalLikes: {
    fontSize: 20, // Increase font size
    textAlign: 'center', // Center align the text
    marginTop: 20, // Add some spacing from the previous section
    fontWeight: 'bold',

  },
  logoutButtonAbsolute: {
    position: 'absolute',
    top: '-8%', // כאן תוכל לכוון את הרווח מהתחתית לפי הצורך
    right: '90%', // כדי למרוחז את הכפתור באמצע המסך
    padding: 10,
    backgroundColor: 'red', // Customize the button color
    borderRadius: 10,
    alignSelf: 'center',
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  sectionHeading: {
    fontSize: 18,
    marginTop: 20,
    marginBottom: 10,
    fontWeight: 'bold',
    textAlign: "right",
  },
  carContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    backgroundColor: '#ff8837',
    borderRadius: 42,
    justifyContent: 'space-between',
    paddingRight: '5%',
  },
  carImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  carName: {
    fontSize: 16,
  },
  noCarsText: {
    fontSize: 16,
    fontStyle: 'italic',
  },
  addCarButton: {
    marginTop: 20,
    marginBottom: 20,
    padding: 10,
    backgroundColor: '#ff5f04',
    borderRadius: 10,
    alignSelf: 'center',
  },
  addCarButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  lockImage: {
    width: 20,
    height: 20,
    marginLeft: 10,
  },
  followCount: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  followLabel: {
    fontSize: 14,
    color: 'gray',
  },
  followContainer: {
    alignItems: 'center',

  },
  followContainer1: {
    alignItems: 'center',
    marginRight: '7%',

  },
  userInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',

    justifyContent: 'center', // Center the items horizontally
    marginBottom: 0,
  },
  avatar: {
    marginRight: `16%`,
    width: 100,
    height: 100,
    borderRadius: 60,
  },
  followCounts: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center the items horizontally
    width: '50%', // Adjusted width for even spacing
  },
  logoutButton: {
    padding: 10,
    backgroundColor: 'red', // Customize the button color
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: 20, // Adjust the margin as needed
  },
  logoutButtonText: {
    color: 'white', // Customize the text color
    fontSize: 16,
    fontWeight: 'bold',
  },



});
