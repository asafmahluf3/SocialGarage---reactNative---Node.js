import React, { useContext, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import { ActivityIndicator } from 'react-native-paper';


export default function SalePage({ route }) {
    const navigation = useNavigation(); // Get the navigation object

    const { carData } = route.params;
    const [price, setPrice] = useState('');
    const [details, setDetails] = useState('');
    const { currentUser, updateSaleDetails, updateIsForSaleTrueInCard } = useContext(UserContext);
    const [remainingChars, setRemainingChars] = useState(300); // Initialize with the maximum limit
    const [isLoading, setIsLoading] = useState(false);


    const handleSaleCar = async () => {
        // Check if price and details are not empty
        if (!price || !details) {
            alert('נא למלא את כל הפרטים');
            return;
        }
    
        setIsLoading(true); // Start loading
    
        const carNumber = carData.carNumber;
    
        // Call the updateSaleDetails function
        const success = await updateSaleDetails(carNumber, price, details);
        const successOfCard = await updateIsForSaleTrueInCard(carNumber);
    
        setIsLoading(false); // Stop loading
    
        if (success && successOfCard) {
            alert('הרכב הועלה למכירה בהצלחה');
            navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
        } else {
            // Failed to update sale details
            alert('בעיה זמנית, אנא נסה מאוחר יותר');
        }
    };
    
    return (
        <View style={styles.container}>
            <Text style={styles.heading}>מכירת רכב</Text>

            <Text style={styles.carDetails}>
                רכב: {carData.manufacturer} {carData.model}
            </Text>

            <TextInput
                style={styles.input1}
                placeholder="מחיר"
                value={price}
                onChangeText={setPrice}
                keyboardType="numeric"
            />
            <TextInput
                style={styles.input2}
                placeholder="פרטים"
                value={details}
                onChangeText={text => {
                    if (text.length <= 300) {
                        setDetails(text);
                    }
                }}
                multiline
                numberOfLines={10}
                textAlignVertical="top"
                maxLength={300}
            />
            <Text style={styles.charCount}>
                {details ? `${details.length}/300` : '0/300'}
            </Text>




            <Text style={styles.loremText}>
               ע”י לחיצה על “פרסם רכב” אתה נותן גישה למשתמשים לצפייה של חלק מהפרטי רכב כמו: ק”מ עדכני ,תאריך טסט יד וכינוי הרכב (פוסטים)
            </Text>

            {isLoading ? (
            <ActivityIndicator size="large" color="#ff5f04" style={styles.loadingIndicator} />
        ) : (
            <TouchableOpacity style={styles.editButton} onPress={handleSaleCar}>
                <Text style={styles.editButtonText}>פרסם רכב</Text>
            </TouchableOpacity>
        )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
    },
    loadingIndicator: {
        marginTop: 20,
    },
    heading: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
    },
    charCount: {
        textAlign: 'right',
        color: '#999',
        marginBottom: 10,
    },
    carDetails: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
    },
    input1: {
        height: 40,
        borderWidth: 1,
        borderColor: '#ff5f04',
        borderRadius: 5,
        marginBottom: 15,
        padding: 10,
        textAlign: "right",
        fontWeight: 'bold',
    },
    input2: {
        borderWidth: 1,
        borderColor: '#ff5f04',
        borderRadius: 5,
        padding: 10,
        textAlign: 'right',
        fontWeight: 'bold',
        paddingTop: 0, // Remove top padding to align text with the top
        height: 150, // Set a fixed height for the input
    },


    loremText: {
        fontSize: 14,
        color: '#666',
        marginBottom: 20,
        textAlign: 'center',
    },
    addButtonText: {
        marginTop: 20,
        padding: 10,
        backgroundColor: '#ff5f04',
        borderRadius: 10,
        alignSelf: 'center',
        fontSize: 16,
        fontWeight: 'bold',
        color: 'black',
    },
    editButton: {
        alignSelf: 'center',
        backgroundColor: '#FF5F04', // Change background color to FF5F04
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 20, // Change border radius to 20
        marginTop: 10,
    },
        editButtonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
    },


});
