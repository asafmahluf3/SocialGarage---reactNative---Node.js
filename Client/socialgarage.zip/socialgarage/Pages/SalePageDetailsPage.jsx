import React, { useContext, useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, ScrollView } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import { format, parse } from 'date-fns';


export default function SalePageDetailsPage({ route }) {
    const navigation = useNavigation();
    const { carData } = route.params;
    const [userId, setUserId] = useState(null);
    const { currentUser } = useContext(UserContext);
    const [testValidityColor, setTestValidityColor] = useState('#008000'); // Default green color


    useEffect(() => {
        const fetchUserIdByCarNumber = async () => {
            try {
                const response = await fetch(`https://socialgarage.onrender.com/api/users/getUserIdByCarNumber/${carData.carNumber}`);
                const data = await response.json();
                setUserId(data.ownerId);
            } catch (error) {
                console.error(error);
            }
        };

        fetchUserIdByCarNumber();

        // Calculate current date and parse testValidity date
        const currentDate = new Date();
        const formattedCurrentDate = format(currentDate, 'dd/MM/yyyy');
        const parsedTestValidity = parse(carData.testValidity, 'dd/MM/yyyy', new Date());

        if (parsedTestValidity < currentDate) {
            setTestValidityColor('#FF0000'); // Set to red if testValidity is in the past
        }
    }, []);
    

    const handleEditSale = () => {
        navigation.navigate('EditSalePage', { carData: carData });
    };

    return (
        <ScrollView style={styles.container}>
            <Image source={{ uri: carData.image }} style={styles.carImage} />

            <View style={styles.detailsContainer}>
                <Text style={styles.carName}>{carData.manufacturer} {carData.model}</Text>
                <Text style={styles.detailsText}>{carData.year}</Text>
                <Text style={styles.detailsText}>בעלות נוכחית: {carData.hand}</Text>
                <Text style={styles.detailsText}>ק"מ עדכני: {carData.currentMileage}</Text>
                <Text style={styles.detailsText}>מספר רכב: {carData.carNumber}</Text>
                <Text style={{ ...styles.testValidity, color: testValidityColor }}> תוקף טסט: {carData.testValidity}  </Text>
            </View>


            <View style={styles.descriptionContainer}>
                <Text style={styles.sectionTitle}>על הרכב:</Text>
                <Text style={styles.detailsText}>{carData.detailsOfSale}</Text>
            </View>
            <Text style={styles.price}>מחיר: {carData.price}₪</Text>
            {currentUser._id === userId && (
                <TouchableOpacity style={styles.editButton} onPress={handleEditSale}>
                    <Text style={styles.editButtonText}>עריכה</Text>
                </TouchableOpacity>
            )}
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F5F5',
    },
    carImage: {
        width: '100%',
        height: 250,
        resizeMode: 'cover',
    },
    detailsContainer: {
        paddingHorizontal: 20,
        paddingTop: 20,
    },
    carName: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 10,
        textAlign: 'right',
    },
    price: {
        fontSize: 18,
        color: '#FF5F04',
        marginBottom: 5,
        textAlign: 'center',
    },
    detailsText: {
        fontSize: 16,
        marginBottom: 5,
        textAlign: 'right',
    },
    testValidity: {
        fontSize: 16,
        color: '#008000',
        marginBottom: 20,
        textAlign: 'right',
    },
    editButton: {
        alignSelf: 'center',
        backgroundColor: '#FF5F04', // Change background color to FF5F04
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 20, // Change border radius to 20
        marginTop: 10,
    },
        editButtonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    descriptionContainer: {
        paddingHorizontal: 20,
        paddingTop: 20,
        backgroundColor: '#FFFFFF',
        borderRadius: 10,
        marginHorizontal: 10,
        marginBottom: 20,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
        textAlign: 'right',
    },
});



