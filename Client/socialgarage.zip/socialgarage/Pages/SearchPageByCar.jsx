import React, { useContext, useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  Modal,
  TouchableWithoutFeedback,
  StyleSheet,
} from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import { FlatList, ScrollView } from 'react-native-gesture-handler';

const SearchPageByCar = () => {
  const navigation = useNavigation();
  const { allCars, currentUser } = useContext(UserContext);
  const [searchInput, setSearchInput] = useState('');
  const [selectedManufacturer, setSelectedManufacturer] = useState('');
  const [selectedModel, setSelectedModel] = useState('');
  const [filteredCars, setFilteredCars] = useState([]);
  const [manufacturerOptions, setManufacturerOptions] = useState([]);
  const [modelOptions, setModelOptions] = useState([]);
  const [isManufacturerDropdownVisible, setIsManufacturerDropdownVisible] = useState(false);
  const [isModelDropdownVisible, setIsModelDropdownVisible] = useState(false);
  const [userNamesByCar, setUserNamesByCar] = useState({});

  const [userId, setUserId] = useState('');
  const [userName, setUserName] = useState('');
  const [profileImage, setProfileImage] = useState('');


  const defaultProfileImage = 'https://static.hudl.com/users/prod/5499830_8e273ea3a64448478f1bb0af5152a4c7.jpg';


  // Extract unique manufacturer and model options from allCars data
  useEffect(() => {
    const uniqueManufacturers = Array.from(
      new Set(
        allCars
          .filter((car) => car.isPrivate === false) // סנן רכבים ששדה isPrivate שלהם הוא false
          .map((car) => car.manufacturer.toLowerCase())
      )
    );
    setManufacturerOptions(uniqueManufacturers);
  }, [allCars]);


  // Update model options when selected manufacturer changes
  useEffect(() => {
    if (selectedManufacturer !== '') {
      const filteredModels = Array.from(
        new Set(
          allCars
            .filter((car) => car.manufacturer.toLowerCase() === selectedManufacturer.toLowerCase())
            .filter((car) => car.isPrivate === false) // סנן רכבים ששדה isPrivate שלהם הוא false
            .map((car) => car.model.toLowerCase())
        )
      );
      setModelOptions(filteredModels);
    } else {
      setModelOptions([]);
    }
  }, [selectedManufacturer]);


  // Update filtered cars when selected manufacturer or model changes
  useEffect(() => {
    const filtered = allCars.filter(
      (car) =>
        (selectedManufacturer === '' || car.manufacturer.toLowerCase() === selectedManufacturer.toLowerCase()) &&
        (selectedModel === '' || car.model.toLowerCase() === selectedModel.toLowerCase()) &&
        car.isPrivate === false // הוסף תנאי זה כדי לסנן רק את הרכבים ש isPrivate שלהם הוא false
    );
    setFilteredCars(filtered);
  }, [selectedManufacturer, selectedModel]);






  const handleCarPress = async (car) => {
    try {
      const response = await fetch(`https://socialgarage.onrender.com/api/users/getFullUserByCarNumber/${car.carNumber}`);
      if (!response.ok) {
        throw new Error(`Request failed with status: ${response.status}`);
      }
      const data = await response.json();

      // שמור את שם המשתמש במשתנה
      setUserName(data.name);


      if (data._id === currentUser._id) {
        navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
      }
      else {
        navigation.navigate('ProfileEachCarSocialGuest', { carData: car, userId: data._id, userName: data.name, profileImage: data.profileImage });
      }
    } catch (error) {
      console.error('Error fetching following list:', error);
    }
  };




  return (
    <View style={styles.container}>
      <TouchableWithoutFeedback onPress={() => setIsManufacturerDropdownVisible(!isManufacturerDropdownVisible)}>
        <View style={styles.dropdownContainer}>
          <Text style={styles.dropdownLabel}>:בחר יצרן</Text>
          <Text style={styles.dropdownValue}>{selectedManufacturer}</Text>
          <Image source={{ uri: 'https://cdn-icons-png.flaticon.com/512/60/60995.png' }} style={styles.dropdownArrow} />
        </View>
      </TouchableWithoutFeedback>
      {isManufacturerDropdownVisible && (
        <ScrollView style={styles.dropdownOptions}>
          {manufacturerOptions.map((manufacturer, index) => (
            <TouchableOpacity
              key={index}
              onPress={() => {
                setSelectedManufacturer(manufacturer);
                setIsManufacturerDropdownVisible(false);
              }}
            >
              <Text style={styles.dropdownOption}>{manufacturer}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {!isManufacturerDropdownVisible && (
        <View>
          <TouchableWithoutFeedback onPress={() => setIsModelDropdownVisible(!isModelDropdownVisible)}>
            <View style={styles.dropdownContainer}>
              <Text style={styles.dropdownLabel}>:בחר דגם</Text>
              <Text style={styles.dropdownValue}>{selectedModel}</Text>
              <Image source={{ uri: 'https://cdn-icons-png.flaticon.com/512/60/60995.png' }} style={styles.dropdownArrow} />
            </View>
          </TouchableWithoutFeedback>
          {isModelDropdownVisible && (
            <ScrollView style={styles.dropdownOptions}>
              {modelOptions.map((model, index) => (
                <TouchableOpacity
                  key={index}
                  onPress={() => {
                    setSelectedModel(model);
                    setIsModelDropdownVisible(false);
                  }}
                >
                  <Text style={styles.dropdownOption}>{model}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}
        </View>
      )}

      {filteredCars.length > 0 && (
        <FlatList
          data={filteredCars}
          keyExtractor={(car) => car._id}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.carButton} onPress={() => handleCarPress(item)}>
              <Image source={{ uri: item.image || defaultProfileImage }} style={styles.carImage} />
              <View style={styles.carInfo}>
                <Text style={[styles.carName, { fontWeight: 'bold' }]}>
                  {item.manufacturer}, {item.model}
                </Text>
                <Text style={styles.ownerName}>{item.ownerName}</Text>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
  },
  dropdownContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 24,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
  },
  dropdownLabel: {
    flex: 1,
    padding: 8,
    fontWeight: 'bold',
  },
  dropdownValue: {
    flex: 3,
    padding: 8,
  },
  dropdownArrow: {
    flex: 1,
    width: 20,
    height: 20,
    resizeMode: 'contain',
  },
  dropdownOptions: {
    borderWidth: 1,
    borderColor: '#ccc',
    maxHeight: 150,
    overflowY: 'scroll',
    borderRadius: 12,
    marginVertical: 8,
  },
  dropdownOption: {
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  carButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 16,
    marginBottom: 24,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  carImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  carInfo: {
    flex: 1,
  },
  carName: {
    fontSize: 18,
    marginBottom: 4,
  },
  ownerName: {
    fontSize: 16,
    color: 'gray',
  },
});

export default SearchPageByCar;
