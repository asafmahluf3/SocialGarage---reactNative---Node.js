import React, { useContext, useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ScrollView, Dimensions, Switch, RefreshControl } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { UserContext } from '../Contexts/UserContextProvider';
import CommentModal from './CommentModal';




const SocialFeedPage = () => {
    const navigation = useNavigation();
    const { allCards, setAllCards, likeCard, currentUser, likeCardOfUser, expoPushToken } = useContext(UserContext);
    const [selectedCarComments, setSelectedCarComments] = useState(null);
    const [selectedCardId, setSelectedCardId] = useState(null);
    const [imageHeights, setImageHeights] = useState({});
    const [showFollowingCars, setShowFollowingCars] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [activeTab, setActiveTab] = useState("all"); // "all" or "following"
    const [expandedCardId, setExpandedCardId] = useState(null); // Track which card's comments are expanded


    const filteredCards = showFollowingCars
        ? allCards.filter(card =>
            currentUser.following.some(followedUser => followedUser._id === card.owner.id)
        )
        : allCards;



    const handleTabChange = (tab) => {
        if (tab === "all") {
            setShowFollowingCars(false);
        } else if (tab === "following") {
            setShowFollowingCars(true);
        }
        setActiveTab(tab);
    };



    const openCommentsModal = (comments, card) => {
        setSelectedCarComments(comments);
        setSelectedCardId(card);
    };

    const closeCommentsModal = () => {
        setSelectedCarComments(null);
    };

    const openCarImage = (carImage) => {
        navigation.navigate('CarImageFullScreen', { carImage });
    };

    const fetchDataFromServer = async () => {
        try {
            const response = await fetch('https://socialgarage.onrender.com/api/cards/cards');
            const data = await response.json();
            return data;
        } catch (error) {
            throw new Error('Error fetching data from the server');
        }
    };

    const fetchUpdatedData = async () => {
        try {
            setIsRefreshing(true);
            const updatedData = await fetchDataFromServer();
            setAllCards(updatedData);
        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setIsRefreshing(false);
        }
    };

    useEffect(() => {
        fetchUpdatedData();
        //const intervalId = setInterval(fetchUpdatedData, 50000000);
        // return () => clearInterval(intervalId);
    }, []);

    const openProfileUser = (card) => {
        if (currentUser._id === card.owner.id) {
            navigation.navigate('TabbedPageNavigator', { screen: 'Profile' });
        } else {
            navigation.navigate('SocialUserPublicCars', { userId: card.owner.id, userName: card.owner.name, profileImage: card.owner.profileImage });
        }
    };

    const determineImageHeight = (imageUri) => {
        Image.getSize(imageUri, (width, height) => {
            if (height > width) {
                setImageHeights((prevHeights) => ({
                    ...prevHeights,
                    [imageUri]: 520,
                }));
            } else {
                setImageHeights((prevHeights) => ({
                    ...prevHeights,
                    [imageUri]: 260,
                }));
            }
        });
    };

    useEffect(() => {
        if (allCards) {
            allCards.forEach((card) => {
                determineImageHeight(card.image);
            });
        }
    }, [allCards]);

    const handleRefresh = async () => {
        try {
            setIsRefreshing(true);
            const updatedData = await fetchDataFromServer();
            setAllCards(updatedData);
        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setIsRefreshing(false);
        }
    };




    return (
        <ScrollView
            style={styles.container}
            refreshControl={
                <RefreshControl
                    refreshing={isRefreshing}
                    onRefresh={handleRefresh}
                />
            }
        >

            <View style={styles.tabContainer}>
                <TouchableOpacity
                    style={[styles.tabButton, activeTab === "all" && styles.activeTab]}
                    onPress={() => handleTabChange("all")}
                >
                    <Text style={[styles.tabButtonText, activeTab === "all" && styles.activeTabText]}>בשבילך</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    style={[styles.tabButton, activeTab === "following" && styles.activeTab]}
                    onPress={() => handleTabChange("following")}
                >
                    <Text style={[styles.tabButtonText, activeTab === "following" && styles.activeTabText]}>במעקב</Text>
                </TouchableOpacity>
            </View>

            {filteredCards && filteredCards.length > 0 ? (
                filteredCards.slice().reverse().map((card, index) => (
                    <View key={index} style={styles.postContainer}>
                        <TouchableOpacity style={styles.carHeader} onPress={() => openProfileUser(card)}>
                            <Image
                                source={{ uri: card.owner?.profileImage || 'https://upload.wikimedia.org/wikipedia/commons/b/bc/Unknown_person.jpg' }}
                                style={styles.avatar}
                            />

                            <Text style={styles.username}>{card.owner?.name || 'Unknown Owner'}</Text>
                        </TouchableOpacity>
                        <View style={styles.carDetailsContainer}>

                            {card.isForSale ? (
                                <Text style={styles.forSaleText}>I'm for sale!</Text>
                            ) : null}


                            <View style={styles.carDetailsTextContainer}>
                                <Text style={styles.carDetailsText}>
                                    {`${card.manufacturer}, ${card.model}`}
                                </Text>
                            </View>
                        </View>

                        <Image
                            source={{ uri: card.image }}
                            style={{ ...styles.carImage, height: imageHeights[card.image] || 200 }}
                        />


                        <View style={styles.carDetailsContainer1}>
                            {/* Like button */}
                            <TouchableOpacity
                                style={styles.actionButtonLike}
                                onPress={() => {
                                    likeCard(card._id);
                                    likeCardOfUser(card.owner.id, card.carNumber, card._id);
                                }}
                            >
                                <Image source={{ uri: 'https://cdn-icons-png.flaticon.com/512/126/126473.png' }} style={styles.actionIcon} />

                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.actionButtonLike}
                                onPress={() => openCommentsModal(card.comments, card)}
                            >
                                {/* ... (comment icon) */}
                                <Image source={{ uri: 'https://cdn2.iconfinder.com/data/icons/medical-healthcare-26/28/Chat-2-512.png' }} style={styles.actionIcon} />

                            </TouchableOpacity>

                        </View>

                        <Text style={styles.likeText}>{card.likes} Likes </Text>
                        <View style={styles.carHeader}>
                            <View style={styles.usernameBioContainer}>
                                <Text style={styles.username1}>{card.owner?.name || 'Unknown Owner'}</Text>
                                {card.imageBio && <Text style={styles.imageBio}>{card.imageBio}</Text>}
                            </View>
                        </View>
                        <TouchableOpacity
                            style={styles.actionButtonComment}
                            onPress={() => openCommentsModal(card.comments, card)}
                        >
                            {/* ... (comment icon) */}
                            <Text style={styles.actionText}>
                                See All Comments ({card.comments ? card.comments.length : 0})
                            </Text>

                        </TouchableOpacity>
                        <View style={styles.actionsContainer}>
                            {/* Show the first three comments */}
                            {card.comments !== undefined && card.comments.length > 0 && (
                                <View>
                                    {card.comments.slice(0, 3).map((comment, commentIndex) => (
                                        <View key={commentIndex} style={styles.commentContainer}>
                                            <Text style={styles.commentUsername}>{comment.userName}:</Text>
                                            <Text style={styles.commentText}> {comment.comment}</Text>

                                        </View>
                                    ))
                                    }

                                    {/* Button to expand and collapse comments */}


                                </View>
                            )}
                        </View>
                        <View style={styles.hr} />
                    </View>
                ))
            ) : (
                <Text style={styles.noCarsText}>No cars available</Text>
            )}

            {/* Render comments modal */}
            {filteredCards.map((card) => (
                (
                    <CommentModal
                        comments={selectedCarComments}
                        card={selectedCardId}
                        onClose={closeCommentsModal}
                    />
                )
            ))}

        </ScrollView>
    );

};

const screenWidth = Dimensions.get('window').width;

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
    },
    carDetailsTextContainer: {
        flex: 1, // Allow the text container to take up remaining space
        alignItems: 'flex-end', // Align the text to the right
    },
    postContainer: {
        marginVertical: 10,
        backgroundColor: '#fff',
        borderRadius: 10,
    },
    carHeader: {
        flexDirection: 'row',
        alignItems: 'center',

        marginLeft: 5,
    },
    avatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
        marginRight: 10,
    },
    username: {
        fontSize: 16,
        fontWeight: 'bold',
    },
    username1: {
        fontSize: 14,
        fontWeight: 'bold',
    },
    usernameBioContainer: {
        flexDirection: 'row', // Place the username and bio side by side
        alignItems: 'center', // Align items vertically within the container
        flex: 1,

    },
    carImage: {
        width: '100%',
        height: 200,
    },
    carDetails: {
        fontSize: 14,
        marginTop: 5,
        textAlign: 'right',
        paddingRight: '5%',
        paddingBottom: '2.5%',
        fontWeight: 'bold',

    },
    carDetailsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 5,
    },
    carDetailsContainer1: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 5,
    },
    carDetailsText: {
        fontSize: 14,
        fontWeight: 'bold',
        paddingRight: '2.5%',
        paddingBottom: '2.5%',
    },
    carimageBio: {
        fontSize: 14,
        marginTop: 5,
        textAlign: 'right',
        paddingRight: '5%',
        fontWeight: 'bold',

    },
    likeText: {
        marginLeft: 5,
        marginTop: 10,

        fontWeight: 'bold',
    },
    imageBio: {
        fontSize: 14,
        color: '#555',
        paddingLeft: '1.5%',
    },
    actionsContainer: {
        flexDirection: 'row',
        fontSize: '10%',
        alignItems: 'center',
        marginTop: 0,
        padding: 10,
    },
    actionButtonLike: {
        flexDirection: 'row',
        alignItems: 'center',
        marginLeft: 7,
        paddingTop: '2%',
    },
    actionButtonComment: {
        flexDirection: 'row',
        alignItems: 'center',
        marginRight: 7,
    },
    actionIcon: {
        width: 24,
        height: 24,
    },
    actionText: {
        paddingTop: '2%',
        fontSize: 14,
        color: '#333',
        paddingLeft: '2.5%',
    },
    noCarsText: {
        fontSize: 16,
        marginTop: 20,
    },
    hr: {
        borderBottomWidth: 1,
        borderBottomColor: '#aaa',
        marginVertical: 10,
        width: "100%",
    },
    switchContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        marginVertical: 10,
    },
    tabContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginBottom: 10,
    },
    tabButton: {
        flex: 1,
        paddingVertical: 10,
        alignItems: 'center',
        backgroundColor: '#eee',
        borderRadius: 10,
        marginHorizontal: 5,
    },
    tabButtonText: {
        fontWeight: 'bold',
    },
    activeTab: {
        backgroundColor: '#ff5f04',
    },
    activeTabText: {
        color: 'white',
    },
    forSaleText: {
        fontSize: 14,
        fontWeight: 'bold',
        color: 'green',
        marginLeft: 10, // Add margin to separate from the left edge
        paddingBottom: '2.5%',

    },
    commentContainer: {
        fontSize: 14,
        flexDirection: 'row',
        fontWeight: 'bold',



    },

    commentUsername: {
        fontWeight: 'bold',


    },


});

export default SocialFeedPage;


