import React, { useContext, useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity, RefreshControl } from 'react-native';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native'; // Import the useNavigation hook

const SocialUserPublicCars = ({ route }) => {
    const navigation = useNavigation(); // Initialize navigation using useNavigation hook

    const { userId, userName, profileImage } = route.params;
    const { currentUser } = useContext(UserContext);


    const [publicCars, setPublicCars] = useState([]);
    const [isFollowing, setIsFollowing] = useState(false);
    let [followersCount, setFollowersCount] = useState(0); // New state
    let [followingCount, setFollowingCount] = useState(0); // New state
    const [totalLikes, setTotalLikes] = useState(0); // New state for total likes
    const [refreshing, setRefreshing] = useState(false);




    useEffect(() => {
        fetchPublicCars();
        checkFollowingStatus();
        fetchFollowersCount();
        fetchFollowingCount();
        fetchTotalLikes(); // Fetch total likes on component mount
    }, []);

    /************************************************כמות עוקבים**********************************************************/
    const fetchFollowersCount = async () => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/${userId}/followers/count`);
            if (!response.ok) {
                throw new Error(`Request failed with status: ${response.status}`);
            }
            const data = await response.json();
            setFollowersCount(data.count);
        } catch (error) {
            console.error('Error fetching followers count:', error);
        }
    };

    // Fetch user's following count
    const fetchFollowingCount = async () => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/${userId}/following/count`);
            if (!response.ok) {
                throw new Error(`Request failed with status: ${response.status}`);
            }
            const data = await response.json();
            setFollowingCount(data.count);
        } catch (error) {
            console.error('Error fetching following count:', error);
        }
    };
    /**********************************************************************************************************************/





    // Check if the current user is following the displayed user
    const checkFollowingStatus = async () => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/${currentUser._id}/following/${userId}`);
            if (!response.ok) {
                throw new Error(`Request failed with status: ${response.status}`);
            }
            const data = await response.json();
            setIsFollowing(data.isFollowing);
        } catch (error) {
            console.error('Error checking following status:', error);
        }
    };


    const handleFollow = async () => {
        try {
            const action = isFollowing ? 'unfollow' : 'follow';
            const response = await toggleFollow(action);

            if (response.ok) {
                setIsFollowing(!isFollowing);
                if (action === 'follow') {
                    setFollowersCount(followersCount + 1); // Increase followers count
                    const Object = {
                        _id: userId,
                        name: userName,
                        profileImage: profileImage,
                    };
                    currentUser.following.push(Object);


                } else {
                    setFollowersCount(followersCount - 1); // Decrease followers count
                    currentUser.following = currentUser.following.filter(user => user._id !== userId);
                }
            } else {
                alert('שגיאה');
            }
        } catch (error) {
            console.error('Error toggling follow status:', error);
        }
    };

    const toggleFollow = async (action) => {
        const url = `https://socialgarage.onrender.com/api/users/${currentUser._id}/${action}/${userId}`;
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-type': 'application/json; charset=UTF-8',
                'Accept': 'application/json; charset=UTF-8',
            },
            body: JSON.stringify({}),

        });
        return response;
    };

    const navigateToCarDetails = (car) => {
        navigation.navigate('ProfileEachCarSocialGuest', { carData: car, userId: userId, userName: userName, profileImage: profileImage });

    };

    // Fetch user's public cars based on the userId
    const fetchPublicCars = async () => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/${userId}/public-cars`);
            if (!response.ok) {
                throw new Error(`Request failed with status: ${response.status}`);
            }
            const data = await response.json();
            setPublicCars(data);
        } catch (error) {
            console.error('Error fetching public cars:', error);
        }
    };


    const fetchTotalLikes = async () => {
        try {
            const response = await fetch(`https://socialgarage.onrender.com/api/users/${userId}/sum-likes`);
            if (!response.ok) {
                throw new Error(`Request failed with status: ${response.status}`);
            }
            const data = await response.json();
            setTotalLikes(data.totalLikes);
        } catch (error) {
            console.error('Error fetching total likes:', error);
        }
    };




    const onRefresh = async () => {
        try {
            setRefreshing(true);
            await fetchFollowersCount()
            await fetchFollowingCount(); // Refresh the total likes      
            await fetchTotalLikes(); // Refresh the total likes
            await fetchPublicCars();
        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setRefreshing(false);
        }
    };



    return (

        <ScrollView
            style={styles.container}
            refreshControl={
                <RefreshControl
                    refreshing={refreshing}
                    onRefresh={onRefresh}
                    colors={['#ff5f04']} // Customize the loading spinner color
                />
            }
        >




            <Text style={styles.name}>{userName}</Text>
            <View style={styles.userInfoContainer}>
                <Image source={{ uri: profileImage }} style={styles.avatar} />



                <TouchableOpacity style={styles.followContainer1} onPress={() => navigation.navigate('FollowersList', { userId })}>
                    <Text style={styles.followCount}>{followersCount}</Text>
                    <Text style={styles.followLabel}>עוקבים</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.followContainer} onPress={() => navigation.navigate('FollowingList', { userId })}>
                    <Text style={styles.followCount}>{followingCount}</Text>
                    <Text style={styles.followLabel}>במעקב</Text>
                </TouchableOpacity>




            </View>
            <TouchableOpacity
                style={styles.followButton}
                onPress={handleFollow}
            >
                <Text style={styles.followButtonText}>
                    {isFollowing ? 'בטל מעקב' : 'מעקב'}
                </Text>
            </TouchableOpacity>
            <Text style={styles.totalLikes}>לייקים :{totalLikes}</Text>
            <Text style={styles.heading}>הרכבים של {userName} </Text>
            {publicCars.map((car, index) => (
                <TouchableOpacity
                    key={index}
                    style={styles.carButton}
                    onPress={() => navigateToCarDetails(car)}
                >
                    <View style={styles.carContainer}>
                        <Image style={styles.carImage} source={{ uri: car.image }} />
                        <Text style={styles.carName}>{car.manufacturer}, {car.model}{car.nickname ? `, ${car.nickname}` : ''}</Text>
                    </View>
                </TouchableOpacity>
            ))}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
    },
    name: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        marginTop: 20,
    },
    userInfoContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 20,
    },
    avatar: {
        marginRight: `16%`,
        width: 100,
        height: 100,
        borderRadius: 60,
    },
    followButton: {
        backgroundColor: '#ff8837',
        borderRadius: 8,
        paddingVertical: 6, // Adjust the padding to make the button smaller
        paddingHorizontal: 20,
        alignSelf: 'center', // Center the button horizontally
        marginBottom: 10, // Add some spacing
    },
    followButtonText: {
        fontSize: 14, // Adjust the font size
        fontWeight: 'bold',
        color: 'white',
        textAlign: 'center', // Center the text horizontally
    },
    followContainer: {
        alignItems: 'center',
    },
    followContainer1: {
        alignItems: 'center',
        marginRight: 20,
    },
    followCount: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    followLabel: {
        fontSize: 14,
        color: 'gray',
    },
    totalLikes: {
        fontSize: 20,
        textAlign: 'center', // Center the text horizontally
        marginTop: 20,
        marginBottom: 20,
        fontWeight: 'bold',
    },

    sectionHeading: {
        fontSize: 18,
        marginTop: 20,
        marginBottom: 10,
        fontWeight: 'bold',
        textAlign: 'right',
    },
    heading
        : {
        fontSize: 18,
        marginTop: 20,
        marginBottom: 10,
        fontWeight: 'bold',
        textAlign: 'left',
    },
    carContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 10,
        backgroundColor: '#ff8837',
        borderRadius: 42,
        justifyContent: 'space-between',
        paddingRight: '5%',
    },
    followContainer1: {
        alignItems: 'center',
        marginRight: '7%',

    },
    userInfoContainer: {
        flexDirection: 'row',
        alignItems: 'center',

        justifyContent: 'center', // Center the items horizontally
        marginBottom: 0,
    },
    carImage: {
        width: 50,
        height: 50,
        borderRadius: 25,
        marginRight: 10,
    },
    carName: {
        fontSize: 16,
    },
    noCarsText: {
        fontSize: 16,
        fontStyle: 'italic',
    },
    addCarButton: {
        marginTop: 20,
        marginBottom: 20,
        padding: 10,
        backgroundColor: '#ff5f04',
        borderRadius: 10,
        alignSelf: 'center',
    },
    addCarButtonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'bold',
    },
});

export default SocialUserPublicCars;
