import React, { useContext, useState } from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, ScrollView, Modal, Pressable } from 'react-native';
import { useNavigation } from '@react-navigation/native';


export default function TahzukaCar({ route }) {
  const { carData } = route.params;
  const navigation = useNavigation();

  // Step 1: State for selected year and list of available years
  const [selectedYear, setSelectedYear] = useState('');
  const availableYears = [...new Set(carData.tahzuka.map(maintenance => maintenance.date.slice(-4)))].sort();

  // Step 2: Function to filter maintenance items by year
  const filterMaintenanceByYear = () => {
    return selectedYear
      ? carData.tahzuka.filter(maintenance => maintenance.date.includes(selectedYear))
      : carData.tahzuka;
  };

  const navigateToProfileEachMaintenance = (maintenance) => {
    navigation.navigate('ProfileEachMaintenance', { carData: maintenance });
  };

  const AddMaintenance = () => {
    navigation.navigate('AddMaintenance', { carData });
  };

  // Step 3: State to manage the visibility of the year menu
  const [isYearMenuVisible, setYearMenuVisible] = useState(false);

  return (
    <View style={styles.container}>
       <View style={styles.coteret1}>
        <Image style={styles.carImage1} source={{ uri: carData.image }} />
        <Text style={styles.carName1}>{carData.manufacturer}</Text>
        <Text style={styles.carName1}>{carData.model}</Text>
        {carData.nickname && <Text style={styles.carName1}> {"("}{carData.nickname}{")"}</Text>}
      </View>
      <Text style={styles.heading}>תחזוקת רכב</Text>

      {/* Step 4: Button to display the year menu */}
      <TouchableOpacity
        style={styles.yearFilterButton}
        onPress={() => setYearMenuVisible(true)}
      >
        <Text style={styles.yearFilterButtonText}>סנן לפי שנה</Text>
      </TouchableOpacity>

      {/* Step 5: Year menu */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={isYearMenuVisible}
        onRequestClose={() => setYearMenuVisible(false)}
      >
        <View style={styles.modalContainer}>
          <ScrollView style={styles.yearMenu}>
            <View style={styles.yearMenuHeader}>
              {/* Close button (X) */}
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setYearMenuVisible(false)}
              >
                <Text style={styles.closeButtonText}>X</Text>
              </TouchableOpacity>

              {/* "בחר שנת טיפול" text */}
              <Text style={styles.yearMenuHeaderText}>בחר שנת טיפול</Text>
            </View>

            {/* Option to display all maintenance items */}
            <Pressable
              style={styles.yearMenuItem}
              onPress={() => {
                setSelectedYear(''); // Clear selected year filter
                setYearMenuVisible(false);
              }}
            >
              <Text style={styles.yearText}>הצג את כל הטיפולים</Text>
            </Pressable>

            {/* Available years */}
            {availableYears.map((year, index) => (
              <Pressable
                key={index}
                style={[
                  styles.yearMenuItem,
                  selectedYear === year && styles.selectedYearMenuItem, // Highlight the selected year
                ]}
                onPress={() => {
                  setSelectedYear(year);
                  setYearMenuVisible(false);
                }}
              >
                <Text style={styles.yearText}>{year}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      </Modal>

      {/* Step 6: Update the mapping to use filtered data */}
      {filterMaintenanceByYear().length > 0 ? (
        <ScrollView>
          {filterMaintenanceByYear().map((maintenance, index) => (
            <TouchableOpacity
              key={index}
              style={styles.carContainer}
              onPress={() => navigateToProfileEachMaintenance(maintenance)}
            >
              <View style={styles.carDetailsContainer}>
                <Text style={styles.carDate}>{maintenance.date} <Text style={styles.hrCombine}>|</Text> </Text>
                <Text style={styles.carName}>{maintenance.name}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      ) : (
        <Text style={styles.noCarsText}>אין טיפולים לרכב זה בשנה שנבחרה</Text>
      )}

      <TouchableOpacity style={styles.addCarButton} onPress={AddMaintenance}>
        <Text style={styles.addCarButtonText}>הוסף טיפול</Text>
      </TouchableOpacity>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  sectionHeading: {
    fontSize: 18,
    marginTop: 20,
    marginBottom: 10,
    textAlign: "right",
  },
  carContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    backgroundColor: '#ff8837',
    borderRadius: 42,
    height: 50,
    justifyContent: 'center',
    textAlign: 'center',
  },
  carImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  carDetailsContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  carName: {
    fontSize: 16,
    flex: 1,
    textAlign: 'right',
    paddingRight: '7%',
  },
  coteret1: {
    flexDirection: "row",
    alignItems: 'center',
    justifyContent: "center",
    textAlign: "center",
    marginBottom: 10,
  },
  carImage1: {
    width: 60,
    height: 60,
    borderRadius: 50,
    marginRight: 10,
  },
  carName1: {
    fontSize: '25%',
    fontWeight: 'bold',
    color: '#333',
  },
  carDate: {
    fontSize: 16,
    textAlign: 'left',
    flex: 1,
    paddingLeft: "5%",
  },
  noCarsText: {
    fontSize: 16,
    fontStyle: 'italic',
  },
  addCarButton: {
    marginTop: 20,
    marginBottom: 20,
    padding: 10,
    backgroundColor: '#ff5f04',
    borderRadius: 10,
    alignSelf: 'center',
  },
  addCarButtonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  hrCombine: {
    fontSize: 20,
  },
  yearFilterButton: {
    alignSelf: 'flex-end',
    paddingVertical: 10,
  },
  yearFilterButtonText: {
    fontSize: 16,
    color: '#007AFF', // or any other color you prefer
    alignSelf: 'center'
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  yearMenu: {
    backgroundColor: '#e2e4e7',
    borderRadius: 10,
    marginHorizontal: 20,
    paddingVertical: 10,
    maxHeight: 300,

  },
  yearMenuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    marginBottom: 10,

  },
  yearMenuHeaderText: {
    fontSize: 16,
    color: 'black',
    fontWeight: 'bold',
  },
  closeButton: {
    alignSelf: 'flex-end',
    padding: 10,
  },
  closeButtonText: {
    fontSize: 16,
    color: 'black',
    fontWeight: 'bold',
  },
  yearMenuItem: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    marginHorizontal: 5,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 5, // Add some margin to separate the years

  },
  selectedYearMenuItem: {
    backgroundColor: '#007AFF', // or any other color you prefer
  },
  yearText: {
    fontSize: 16,
    color: 'black',
    textAlign: 'center', // Center the year text

  },

});
