import React, { useContext, useState, useEffect } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    Platform,
    Keyboard,
    TouchableWithoutFeedback,
    Alert,
    Image,
    KeyboardAvoidingView,
    ActivityIndicator,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { UserContext } from '../Contexts/UserContextProvider';
import { useNavigation } from '@react-navigation/native';
import { ScrollView } from 'react-native-gesture-handler';
import cheerio from 'cheerio';
import { v4 as uuidv4 } from 'uuid';



export default function UploadImageSocial({ route }) {
    const { carData, imageToUpload } = route.params;

    const navigation = useNavigation();
    const { addCardToCar, currentUser, addNewCard } = useContext(UserContext);


    const [imageBio, setImageBio] = useState("");










    const handleUploadImage = async () => {

        const newCard = {
            _id: uuidv4(), // Generate a random ID
            image: imageToUpload,
            likes: 0,
            likedBy: [],
            comments: [],
            imageBio: imageBio,
            owner: {
                id: currentUser._id,
                name: currentUser.name,
                profileImage: currentUser.profileImage,
            },
            manufacturer: carData.manufacturer,
            model: carData.model,
            nickname: carData.nickname,
            carNumber: carData.carNumber,
            isForSale: carData.isForSale,
        };

        const uploadSuccess = await addCardToCar(carData.carNumber, newCard);
        const updatedCarData = { ...carData, cards: [...carData.cards, newCard] };

        if (uploadSuccess) {
            console.log('Car added to user');
        } else {
            console.log('Failed to upload image');
        }

        if (!carData.isPrivate) {

            const success = await addNewCard(newCard);

            if (success) {
                // Card added successfully, handle success
                alert('הפוסט הועלה');
                navigation.navigate('ProfileEachCarSocial', { carData: updatedCarData });
            } else {
                // Failed to add card, handle error
                alert('שגיאה בהעלאת פוסט');
            }
        }




    };





    const dismissKeyboard = () => {
        Keyboard.dismiss();
    };

    return (
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
            <ScrollView contentContainerStyle={styles.container}>
                <Text style={styles.heading}>העלאת פוסט</Text>

                <View style={styles.imageContainer}>
                    {imageToUpload && <Image source={{ uri: imageToUpload }} style={styles.selectedImage} />}

                </View>

                <Text style={styles.upText}>תיאור :</Text>
                <View style={styles.inputContainer}>
                    <TextInput
                        style={styles.input}
                        placeholder="הזן תיאור לתמונה"
                        value={imageBio}
                        onChangeText={setImageBio}
                        placeholderTextColor="#aaa"
                        multiline
                    />
                </View>

                <TouchableOpacity style={styles.addButton} onPress={handleUploadImage}>
                    <Text style={styles.addButtonText}>העלאת הפוסט</Text>
                </TouchableOpacity>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        width: "100%",
    },

      heading: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
      },
      imageContainer: {
        alignItems: 'center',
        marginBottom: 20,
      },
      imageButton: {
        padding: 10,
        backgroundColor: '#fff',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#ff5f04',
      },
      buttonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
      },
      selectedImage: {
        width: 300,
        height: 300,
        borderRadius: 10,
        marginBottom: 10,
      },
      upText: {
        textAlign: 'right',
        marginBottom: 3,
        marginRight: 3,
        fontWeight: 'bold',
      },
      input: {
        height: 40,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        marginBottom: 10,
        padding: 10,
        borderColor: '#ff5f04',
        fontWeight: 'bold',
        textAlign: 'right',
      },
      addButton: {
        marginTop: 20,
        padding: 10,
        backgroundColor: '#ff5f04',
        borderRadius: 10,
      },
      addButtonText: {
        color: 'black',
        fontSize: 16,
        fontWeight: 'bold',
        textAlign: 'center',
      },
    });
