import React, { useContext, useEffect, useRef, useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Dimensions, Animated } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { UserContext } from '../Contexts/UserContextProvider';


// import * as Device from 'expo-device';
// import * as Notifications from 'expo-notifications';

// Notifications.setNotificationHandler({
//     handleNotification: async () => ({
//         shouldShowAlert: true,
//         shouldPlaySound: false,
//         shouldSetBadge: false,
//     }),
// });

// async function sendPushNotification(expoPushToken, coteret, msg) {
//     const message = {
//         to: expoPushToken,
//         sound: 'default',
//         title: coteret,
//         body: msg,
//         data: { someData: 'goes here' },
//     };

//     await fetch('https://exp.host/--/api/v2/push/send', {
//         method: 'POST',
//         headers: {
//             Accept: 'application/json',
//             'Accept-encoding': 'gzip, deflate',
//             'Content-Type': 'application/json',
//             'Accept': 'application/json; charset=UTF-8',
//         },
//         body: JSON.stringify(message),
//     });
// }

// async function registerForPushNotificationsAsync() {
//     let token;
//     if (Device.isDevice) {
//         const { status: existingStatus } = await Notifications.getPermissionsAsync();
//         let finalStatus = existingStatus;
//         if (existingStatus !== 'granted') {
//             const { status } = await Notifications.requestPermissionsAsync();
//             finalStatus = status;
//         }
//         if (finalStatus !== 'granted') {
//             alert('Failed to get push token for push notification!');
//             return;
//         }
//         token = (await Notifications.getExpoPushTokenAsync()).data;
//         console.log(token);
//     } else {
//         alert('Must use physical device for Push Notifications');
//     }

//     if (Platform.OS === 'android') {
//         Notifications.setNotificationChannelAsync('default', {
//             name: 'default',
//             importance: Notifications.AndroidImportance.MAX,
//             vibrationPattern: [0, 250, 250, 250],
//             lightColor: '#FF231F7C',
//         });
//     }
//     return token;
// }


export default function WelcomePage() {
    const navigation = useNavigation();
    const { fromLoginToCheckIfExist, expoPushToken, setExpoPushToken } = useContext(UserContext);


    // const [notification, setNotification] = useState(false);
    // const notificationListener = useRef();
    // const responseListener = useRef();



    // useEffect(() => {
    //     registerForPushNotificationsAsync().then(token => setExpoPushToken(token));

    //     notificationListener.current = Notifications.addNotificationReceivedListener(notification => {
    //         setNotification(notification);
    //     });

    //     responseListener.current = Notifications.addNotificationResponseReceivedListener(response => {
    //         console.log(response);
    //     });


    //     return () => {
    //         Notifications.removeNotificationSubscription(notificationListener.current);
    //         Notifications.removeNotificationSubscription(responseListener.current);
    //     };
    // }, []);










    useEffect(() => {
        // Check if stored credentials exist
        const checkStoredCredentials = async () => {
            const userEmail = await AsyncStorage.getItem('userEmail');
            const userPassword = await AsyncStorage.getItem('userPassword');

            if (userEmail && userPassword) {
                const userExists = await fromLoginToCheckIfExist(userEmail, userPassword);
                if (userExists) {
                    navigation.reset({
                        index: 0,
                        routes: [{ name: 'TabbedPageNavigator' }],
                    });
                }
            }
        };
        checkStoredCredentials();
    }, []);






    const imageAnim = useRef(new Animated.Value(0)).current;
    const buttonAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.parallel([
            Animated.timing(imageAnim, {
                toValue: 1,
                duration: 2000,
                useNativeDriver: true,
            }),
            Animated.timing(buttonAnim, {
                toValue: 1,
                duration: 1000,
                delay: 1500,
                useNativeDriver: true,
            }),
        ]).start();
    }, [imageAnim, buttonAnim]);

    return (
        <View style={styles.container}>
            <Text style={styles.heading}>Social garage</Text>

            <Animated.View
                style={[
                    styles.imageContainer,
                    {
                        opacity: imageAnim,
                        transform: [
                            {
                                translateY: imageAnim.interpolate({
                                    inputRange: [0, 1],
                                    outputRange: [100, 0],
                                }),
                            },
                        ],
                    },
                ]}
            >
                <Image
                    source={require('../Images/carImage.png')}
                    style={styles.image}
                    resizeMode="contain"
                />
            </Animated.View>

            <Text style={styles.sentence}>For car lovers by car lovers</Text>

            <Animated.View
                style={[
                    styles.buttonContainer,
                    {
                        opacity: buttonAnim,
                        transform: [
                            {
                                translateY: buttonAnim.interpolate({
                                    inputRange: [0, 1],
                                    outputRange: [100, 0],
                                }),
                            },
                        ],
                    },
                ]}
            >
                <TouchableOpacity
                    style={styles.button}
                    onPress={() => navigation.navigate('LoginPage')}
                >
                    <Text style={styles.buttonText}>התחברות</Text>
                </TouchableOpacity>
            </Animated.View>

            <Animated.View
                style={[
                    styles.buttonContainer,
                    {
                        opacity: buttonAnim,
                        transform: [
                            {
                                translateY: buttonAnim.interpolate({
                                    inputRange: [0, 1],
                                    outputRange: [100, 0],
                                }),
                            },
                        ],
                    },
                ]}
            >
                <TouchableOpacity
                    style={styles.button}
                    onPress={() => navigation.navigate('RegisterPage')}
                >
                    <Text style={styles.buttonText}>הרשמה</Text>
                </TouchableOpacity>
            </Animated.View>
        </View>
    );
}

const windowWidth = Dimensions.get('window').width;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        paddingBottom: '30%',
        width: '100%',
    },
    heading: {
        fontSize: 32,
        fontWeight: 'bold',
        paddingBottom: '20%',
        fontFamily: 'CourierNewPSMT',


    },
    imageContainer: {
        width: windowWidth,
        height: '20%',
        alignItems: 'center',
        padding: 10,

    },
    image: {
        width: '100%',
        height: '100%',

    },
    sentence: {
        fontSize: 18,
        marginBottom: 130,
        fontFamily: 'CourierNewPSMT',

    },
    buttonContainer: {
        backgroundColor: '#ff5f04',
        borderRadius: 20,
        padding: 10,
        width: '80%',
        alignItems: 'center',
        marginVertical: 10,
    },
    button: {
        alignItems: 'center',
        width: '100%',
    },
    buttonText: {
        color: 'black',
        fontWeight: 'bold',
    },
});
