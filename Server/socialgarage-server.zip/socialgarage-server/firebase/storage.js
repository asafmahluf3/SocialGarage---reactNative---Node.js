import { Storage } from "@google-cloud/storage";

// Firebase config
const firebaseConfig = {

    credentials: {
        "type": "service_account",
        "project_id": "socialgarage-33239",
        "private_key_id": "f2c1681d78a84eb4c31637f26a09ac0b5b2d8777",
        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCZ7gvo45aHoiYp\nEGOXJqXwHdSdz0GV6scMv9u30Adx/ChOulkJkYX7z0+1dygR2pDryoHYzbmK2Afm\njJj3k2aolUOg6fuufalO/sHZ4Ai8dMY79uhfJbL4y88CoagWLbnNttmb4cec3Mdp\nry4GB3iVtfhB3x52xpF1vY0N9f5fp05aRnq+dpYUe5rXd4slJmrP39Yahns+Nwe4\nNYN0Z6rO9bEEdt9aLFoXchwv42tvgEZ9ax+CIIpUZZD4yOExXklcjhi/33cKbssi\n/Xi4QE1vH4m+mSLhL56Dw+50o8dD1sw8zpIPQrfB+6/AyODUZ2FE27MWdL9q3YDc\ndWpBHrdvAgMBAAECggEAD0QD61tSzO3AUhc9gTqEf2097k6lJvyLNBD89dxMOLo0\ntyYU+XV0r7XuJkWEdEzUTYYeXYV9jq8BDZTJANid+D8hX16FJtdwiJSMXhKxWxtL\no5vHjNQczT7NL2of1N9BC41ERIjeNojQwALvEgsAovxSfBnoGAh2WZJsYEOSsCKs\ngfMTygRTu4/h/U5fPfDxhc3jt00TuTZZiFyElyA3ua5Mr2oRAjnM+6nfJ5dWio0g\ntoWTYqqmBFyEN09+oGQDdXSebp8Erz9XXpcDVkJ9gIsK99dS433DGDIsayLEEyH0\nxeW/UP6fecyUH5WG7qg6EiIKhcghzMTZ2utdnBYM2QKBgQDZUy/ehMnBtuDpBEhm\nBeZJEhEwioza//ar6I6ooYHUEFR/V5cn5X/MaUj+kfbFbdbm1ctWYJIjD/Vceya8\nX1fw3+uCBrwS/V5wTp3L989h+/SliVPny9gLkY/jFoi0SnlN0FYCtNaokoDgXEvv\n00uu26DYiSwWWNBhmjobKsUlpwKBgQC1UrqcayQ0JB0Lx2Scoazm9x6kaaOuXzdK\nMlDaj+gwMq8zndZslokEfpsSQUjyvOxrs5YtwcirkKv5BbCP64DJv0uvMXMjhgrB\n1Lubw9DHaKtBXUvl4B+ZzRv5WvKOPeD5OHBl94q0PhIZ40poC9XGXc2WFVyvksip\nV1WykA0o+QKBgF01PHanZRDcKqJF3/dB2H7GbPDwu3DCDz2zxFu2yUP2rQbgvkey\nOpmlHlVwrPIIJf9i+o7VZFf9ZDKB7x8jlUgOAagG02shl/t6/FqasitIMKk+uOnV\nl5d+msO+ymro9hXVoM4QWXB7RSL08uytJuyb7eRxEKOU++qghwNX2K5JAoGASYly\nu0tMlITs7sEAEfIT4Fvqpn1db7OYBdRgLDPe0+VKXuGte76VdSgvlfi6MA/kxk1A\nI/CKhOIYjNb843F8etXFSRkB/C85n6C6MZL50lWl1s2SoXkC9+pSZQ+4fW2lFw4H\nr6L0MuNVjgA7RfU+zsNuRGcHfwFFtkAANnnrjGkCgYAsTRlhphQCSfwdSnliNSIj\n0XQa2KIhDLfS9IDCXOk/ZSZMnwBndcFeADUTNAOrR1SOcJamM0l8Q6eqnUDMCIDf\nIScBAxtvbu79KWEFYr5D1Kktzf2FffBcBv6WKD5IUOArDg4RdmefghFDgiWuA/EJ\nGPOB0BA2DGELLf9cXeLXQw==\n-----END PRIVATE KEY-----\n",
        "client_email": "firebase-adminsdk-zzelv@socialgarage-33239.iam.gserviceaccount.com",
        "client_id": "107319998218682763850",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-zzelv%40socialgarage-33239.iam.gserviceaccount.com",
        "universe_domain": "googleapis.com"
    },
    projectId: "socialgarage-33239",
    bucketName: "socialgarage-33239.appspot.com",
    apiKey: "AIzaSyDI6FNjNFggBRjJEcaoJupJKULbNBCapOU",
    authDomain: "socialgarage-33239.firebaseapp.com",
    projectId: "socialgarage-33239",
    storageBucket: "socialgarage-33239.appspot.com",
    messagingSenderId: "1036338893056",
    appId: "1:1036338893056:web:cf5c61c5355a41c93da3e5"
};


// Initialize Google Cloud Storage
const storage = new Storage(firebaseConfig);

export const bucket = storage.bucket(firebaseConfig.bucketName);


