const { Storage } = require("@google-cloud/storage");
const path = require("path");

async function uploadImageToFirebase(file, filePath) {
    const storage = new Storage();
    const bucket = storage.bucket("socialgarage-33239.appspot.com");

    // Extract the original file extension
    const originalExtension = path.extname(file.originalname);

    // Combine the filePath with the original file extension to create the new filename
    const filename = filePath + originalExtension;

    // Upload the file to Firebase Cloud Storage
    const blob = bucket.file(filename);

    const blobStream = blob.createWriteStream({
        metadata: {
            contentType: file.mimetype,
        },
    });

    const blobPromise = new Promise((resolve, reject) => {
        blobStream.on("error", (err) => {
            reject(err);
        });

        blobStream.on("finish", async () => {
            // Get URL of the uploaded file
            const publicUrl = `https://firebasestorage.googleapis.com/v0/b/${bucket.name
                }/o/${encodeURIComponent(blob.name)}?alt=media`;
            resolve(publicUrl);
        });
    });

    blobStream.end(file.buffer);
    return await blobPromise;
}

module.exports = uploadImageToFirebase;
