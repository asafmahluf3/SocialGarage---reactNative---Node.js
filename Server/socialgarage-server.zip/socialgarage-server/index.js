require('dotenv').config();
const express = require('express');
const CORS = require('cors');
const PORT = process.env.PORT || 5500;

const server = express();
server.use(express.json({ limit: '50000000mb', extended: true }));
server.use(express.urlencoded({ limit: '50000000mb', extended: true }));
server.use(CORS());


server.get('/', async (req, res) => {
  res.send('hiiii');
});

// Import routes
const userRoute = require('./routes/routesUsers');
const warningLightRoute = require('./routes/routesWarningLights');
const garageRoute = require('./routes/routesGarages');
const cardRoute = require('./routes/routesCards');

// Use routes
server.use('/api/users', userRoute);
server.use('/api/warning-lights', warningLightRoute);
server.use('/api/garages', garageRoute);
server.use('/api/cards', cardRoute);


server.listen(PORT, () => console.log(`http://localhost:${PORT}`));
