const DB = require('../utils/DB');

class Card {
  static collection = 'cards';

  _id; // (string, not object id)
  image;
  likes;
  likedBy; // Array to store user IDs who have liked the card
  comments;
  imageBio;
  owner;
  manufacturer;
  model;
  nickname;
  carNumber;
  isForSale;

  constructor(_id, image, likes, likedBy, comments, imageBio, owner, manufacturer, model, nickname, carNumber, isForSale) {
    this._id = _id;
    this.image = image;
    this.likes = likes;
    this.likedBy = likedBy || []; // Initialize likedBy as an empty array if not provided
    this.comments = comments || [];
    this.imageBio = imageBio;
    this.owner = owner;
    this.manufacturer = manufacturer;
    this.model = model;
    this.nickname = nickname;
    this.carNumber = carNumber;
    this.isForSale = isForSale;

  }

  static async FindAllCards() {
    return await new DB().FindAll(Card.collection);
  }


  static async FindById(id) {
    return await new DB().FindByCardID(Card.collection, id);
  }

  async InsertOne() {
    try {
      const result = await new DB().Insert(Card.collection, this);
      return result;
    } catch (error) {
      console.error('Failed to insert document:', error);
      return error;
    }
  }

  static async UpdateById(id, updatedData) {
    return await new DB().UpdateByCardId(Card.collection, id, updatedData);
  }




  static async LikeCardById(id, userId) {
    try {
      // Fetch the card by ID
      const card = await Card.FindById(id);
      if (!card) {
        throw new Error('Card not found');
      }

      // Check if the user has already liked the card
      const userIndex = card.likedBy.indexOf(userId);
      if (userIndex !== -1) {
        // User has already liked the card, remove like
        card.likes -= 1;
        card.likedBy.splice(userIndex, 1);
      } else {
        // User hasn't liked the card, add like
        card.likes += 1;
        card.likedBy.push(userId);
      }

      // Update the card in the database
      await Card.UpdateById(id, { likes: card.likes, likedBy: card.likedBy });

      return card;
    } catch (error) {
      console.error('Failed to update likes for card:', error);
      throw error;
    }
  }


  // Inside your Card class definition
  static async DeleteManyByQuery(query) {
    try {
      const db = new DB();
      const result = await db.DeleteMany(Card.collection, query);
      return result;
    } catch (error) {
      console.error('Failed to delete documents:', error);
      return error;
    }
  }



  static async FindMany(query = {}, projection = {}) {
    try {
      return await new DB().FindMany(Card.collection, query, projection);
    } catch (error) {
      console.error('Failed to fetch documents:', error);
      return error;
    }
  }


  static async UpdateImageBioById(id, newImageBio) {
    try {
      await new DB().UpdateByCardId(Card.collection, id, { imageBio: newImageBio });
    } catch (error) {
      console.error('Failed to update imageBio for card:', error);
      throw error;
    }
  }




  // Inside your Card class definition
  static async DeleteById(id) {
    try {
      const db = new DB();
      const result = await db.DeleteOne(Card.collection, { _id: id }); // Pass the _id as a string
      return result;
    } catch (error) {
      console.error('Failed to delete card:', error);
      return false;
    }
  }







}

module.exports = Card;

