const DB = require('../utils/DB');

class Garage {
  static collection = 'garages';

  name;
  longitude; // Added longitude property
  latitude; // Added latitude property
  city;
  address;
  garageCompany;
  phoneNumber;
  reviews = [];

  constructor(name, longitude, latitude, city, address, garageCompany, phoneNumber, reviews) {
    this.name = name;
    this.longitude = longitude; // Initialize longitude
    this.latitude = latitude;   // Initialize latitude
    this.city = city;
    this.address = address;
    this.garageCompany = garageCompany;
    this.phoneNumber = phoneNumber;
    this.reviews = reviews || [];
  }

  static async FindAllGarages() {
    return await new DB().FindAll(Garage.collection);
  }

  static async FindById(id) {
    return await new DB().FindById(Garage.collection, id);
  }


  async InsertOne() {
    try {
      const result = await new DB().Insert(Garage.collection, this);
      return result;
    } catch (error) {
      console.error('Failed to insert garage:', error);
      throw error;
    }
  }


  async Update() {
    try {
      const result = await new DB().UpdateById(Garage.collection, this._id, this);
      return result;
    } catch (error) {
      console.error('Failed to update garage:', error);
      throw error;
    }
  }

  static async DeleteById(id) {
    try {
      const result = await new DB().DeleteById(Garage.collection, id);
      return result;
    } catch (error) {
      console.error('Failed to delete garage:', error);
      throw error;
    }
  }
}

module.exports = Garage;
