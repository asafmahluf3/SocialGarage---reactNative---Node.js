const DB = require('../utils/DB');
const bcrypt = require('bcrypt'); // Add this line to import bcrypt

class User {
  static collection = 'users';

  email;
  name;
  password;
  profileImage;
  followers = []; // Array of user IDs who follow this user
  following = []; // Array of user IDs whom this user follows
  cars;

  constructor(email, name, password, profileImage, followers, following, cars) {
    this.email = email;
    this.name = name;
    this.password = password;
    this.profileImage = profileImage;
    this.followers = followers || [];
    this.following = following || [];
    this.cars = cars;
  }

  static async FindAllUsers() {
    return await new DB().FindAll(User.collection);
  }

  static async FindById(id) {
    return await new DB().FindByID(User.collection, id);
  }


  async InsertOne() {
    try {
      // Hash the password before saving it
      this.password = await bcrypt.hash(this.password, 10);

      const result = await new DB().Insert(User.collection, this);
      return result;
    } catch (error) {
      console.error('Failed to insert document:', error);
      return error;
    }
  }


  static async FindByEmail(email) {
    return await new DB().FindOne(User.collection, { email });
  }

  static async FindByName(name) {
    try {
      return await new DB().FindOne(User.collection, { name });
    } catch (error) {
      throw error;
    }
  }


  static async FindUserByCar(car) {
    return await new DB().FindOne(User.collection, { 'cars.carNumber': car.carNumber });
  }

  static async UpdateById(id, updatedData) {
    return await new DB().UpdateById(User.collection, id, updatedData);
  }

  static async UpdateByEmail(email, updatedData) {
    return await new DB().UpdateByEmail(User.collection, email, updatedData);
  }


  static async AddCommentToCard(userId, carNumber, cardId, userName, comment) {
    try {
      const user = await User.FindById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      const car = user.cars.find((car) => car.carNumber === carNumber);
      if (!car) {
        throw new Error('Car not found');
      }

      const card = car.cards.find((card) => card._id === cardId);
      if (!card) {
        throw new Error('Card not found');
      }

      const newComment = { userName, comment };
      card.comments.push(newComment);

      await User.UpdateById(userId, user);

      return user;
    } catch (error) {
      throw error;
    }
  }


  static async FindUsersByName(name) {
    try {
      const users = await new DB().Find(User.collection, { name });
      return users;
    } catch (error) {
      console.error('Failed to find users by name:', error);
      return [];
    }
  }



  static async Follow(userId, userIdToFollow) {
    try {
      const userToFollow = await User.FindById(userIdToFollow);
      if (!userToFollow) {
        throw new Error('User to follow not found');
      }

      const currentUser = await User.FindById(userId); // Fetch current user

      // Check if the current user is already following the target user
      if (currentUser.following.includes(userIdToFollow)) {
        return { message: 'User is already following this user' };
      }

      // Add the userIdToFollow to the current user's following list
      currentUser.following.push({ _id: userIdToFollow, name: userToFollow.name, profileImage: userToFollow.profileImage });

      // Add the current user's ID to the userToFollow's followers list
      userToFollow.followers.push({ _id: userId, name: currentUser.name, profileImage: userToFollow.profileImage });

      await User.UpdateById(userIdToFollow, userToFollow);
      const result = await User.UpdateById(userId, currentUser);

      return result;
    } catch (error) {
      throw error;
    }
  }

  static async Unfollow(userId, userIdToUnfollow) {
    try {
      const userToUnfollow = await User.FindById(userIdToUnfollow);
      if (!userToUnfollow) {
        throw new Error('User to unfollow not found');
      }

      const currentUser = await User.FindById(userId); // Fetch current user

      // Check if the current user is following the target user
      const followingIndex = currentUser.following.findIndex(
        (user) => user._id === userIdToUnfollow
      );

      if (followingIndex === -1) {
        return { message: 'User is not following this user' };
      }

      // Remove the userIdToUnfollow from the current user's following list
      currentUser.following.splice(followingIndex, 1);

      // Find the index of the current user in the followers list of the userToUnfollow
      const followersIndex = userToUnfollow.followers.findIndex(
        (user) => user._id === userId
      );

      if (followersIndex !== -1) {
        // Remove the current user's ID from the userToUnfollow's followers list
        userToUnfollow.followers.splice(followersIndex, 1);
      }

      await User.UpdateById(userIdToUnfollow, userToUnfollow);
      const result = await User.UpdateById(userId, currentUser);

      return result;
    } catch (error) {
      throw error;
    }
  }


  static async FindByIds(ids) {
    try {
      const db = new DB();
      const users = await db.FindMany(User.collection, { _id: { $in: ids } });
      return users;
    } catch (error) {
      throw error;
    }
  }




}

module.exports = User;
