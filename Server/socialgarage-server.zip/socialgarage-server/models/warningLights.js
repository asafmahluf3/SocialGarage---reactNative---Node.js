const DB = require('../utils/DB');

class WarningLight {
  static collection = 'warning_lights';

  lightCode;
  lightDescription;
  riskLevel;
  lightImage;

  constructor(lightCode, lightDescription, riskLevel, lightImage) {
    this.lightCode = lightCode;
    this.lightDescription = lightDescription;
    this.riskLevel = riskLevel;
    this.lightImage = lightImage;
  }

  static async FindAllWarningLights() {
    return await new DB().FindAll(WarningLight.collection);
  }

  static async FindByLightCode(lightCode) {
    return await new DB().FindByID(WarningLight.collection, { lightCode });
  }

  async InsertOne() {
    return await new DB().Insert(WarningLight.collection, this);
  }
}

module.exports = WarningLight;
