
const Card = require('../models/card');
const cardRoute = require('express').Router();





// Route for getting all cards
cardRoute.get('/cards', async (req, res) => {
    try {
        const cards = await Card.FindAllCards();
        res.json(cards);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch cards.' });
    }
});


// Route for adding a new card
cardRoute.post('/add', async (req, res) => {
    try {
        const { _id, image, likes, likedBy, comments, imageBio, owner, manufacturer, model, nickname, carNumber, isForSale } = req.body;
        const card = new Card(_id, image, likes, likedBy, comments, imageBio, owner, manufacturer, model, nickname, carNumber, isForSale);

        const result = await card.InsertOne();
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: 'Failed to add the card.' });
    }
});

cardRoute.post('/:id/like/:userId', async (req, res) => {
    try {
        const { id, userId } = req.params;

        const card = await Card.LikeCardById(id, userId);
        res.status(200).json(card);
    } catch (error) {
        if (error.message === 'Card not found' || error.message === 'User has already liked this card') {
            res.status(400).json({ error: error.message });
        } else {
            res.status(500).json({ error: 'An error occurred' });
        }
    }
});









cardRoute.post('/:id/add-comment', async (req, res) => {
    try {
        const { id } = req.params;
        const { userName, comment } = req.body;

        // Fetch the card by ID
        const card = await Card.FindById(id);
        if (!card) {
            return res.status(404).json({ error: 'Card not found' });
        }

        // Create a new comment object
        const newComment = { userName, comment };

        // Add the new comment to the card's comments array
        card.comments.push(newComment);

        // Update the card in the database with the new comments array
        await Card.UpdateById(id, { comments: card.comments });

        // Return the updated card with the new comment added
        return res.status(200).json(card);
    } catch (error) {
        console.error('Failed to add comment to card:', error);
        res.status(500).json({ error: 'An error occurred while adding the comment' });
    }
});



// Route for deleting all cards with a specific carNumber
cardRoute.delete('/delete-by-carNumber/:carNumber', async (req, res) => {
    try {
        const carNumber = req.params.carNumber;
        console.log(carNumber);
        const query = { carNumber }; // Create a query to find cards with the specified carNumber
        const result = await Card.DeleteManyByQuery(query); // Add this method to your Card class
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete cards.' });
    }
});




cardRoute.post('/update-owner-info', async (req, res) => {
    try {
        const { carNumber, newOwnerId, newOwnerName, newProfileImage } = req.body;

        // Find cards with the specified carNumber
        const cards = await Card.FindMany({ carNumber }); // Implement FindMany in your Card model

        if (cards.length === 0) {
            return res.status(404).json({ error: 'No cards found with the specified carNumber' });
        }

        // Update each card's owner information
        const updatedCards = [];
        for (const card of cards) {
            const updatedCard = await Card.UpdateById(card._id, {
                owner: { id: newOwnerId, name: newOwnerName, profileImage: newProfileImage }
            });
            updatedCards.push(updatedCard);
        }

        res.json({ message: 'Owner info updated successfully', updatedCards });
    } catch (error) {
        console.error('Failed to update owner info:', error);
        res.status(500).json({ error: 'An error occurred while updating owner info' });
    }
});



// Add this route to your existing cardRoute
cardRoute.post('/set-for-sale/:carNumber', async (req, res) => {
    try {
        const { carNumber } = req.params;

        // Find cards with the specified carNumber
        const cards = await Card.FindMany({ carNumber });

        if (cards.length === 0) {
            return res.status(404).json({ error: 'No cards found with the specified carNumber' });
        }

        // Update each card's isForSale property to true
        const updatedCards = [];
        for (const card of cards) {
            const updatedCard = await Card.UpdateById(card._id, { isForSale: true });
            updatedCards.push(updatedCard);
        }

        res.json({ message: 'isForSale updated successfully', updatedCards });
    } catch (error) {
        console.error('Failed to update isForSale:', error);
        res.status(500).json({ error: 'An error occurred while updating isForSale' });
    }
});




// Add this route to your existing cardRoute
cardRoute.post('/set-not-for-sale/:carNumber', async (req, res) => {
    try {
        const { carNumber } = req.params;

        // Find cards with the specified carNumber
        const cards = await Card.FindMany({ carNumber }); // Implement FindMany in your Card model

        if (cards.length === 0) {
            return res.status(404).json({ error: 'No cards found with the specified carNumber' });
        }

        // Update each card's isForSale property to false
        const updatedCards = [];
        for (const card of cards) {
            const updatedCard = await Card.UpdateById(card._id, { isForSale: false });
            updatedCards.push(updatedCard);
        }

        res.json({ message: 'isForSale updated successfully', updatedCards });
    } catch (error) {
        console.error('Failed to update isForSale:', error);
        res.status(500).json({ error: 'An error occurred while updating isForSale' });
    }
});




// Route for updating imageBio for a card by ID
cardRoute.post('/:id/updateImageBio', async (req, res) => {
    try {
        const { id } = req.params;
        const { newImageBio } = req.body;

        // Update the imageBio for the card by ID
        await Card.UpdateImageBioById(id, newImageBio.imageBio);

        res.status(200).json({ message: 'ImageBio updated successfully' });
    } catch (error) {
        console.error('Failed to update imageBio for card:', error);
        res.status(500).json({ error: 'An error occurred while updating imageBio' });
    }
});


// Route for deleting a card by ID
cardRoute.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        // Delete the card by ID
        const result = await Card.DeleteById(id);

        if (!result) {
            return res.status(404).json({ error: 'Card not found' });
        }

        res.json({ message: 'Card deleted successfully' });
    } catch (error) {
        console.error('Failed to delete card:', error);
        res.status(500).json({ error: 'An error occurred while deleting the card' });
    }
});







module.exports = cardRoute;
