const Garage = require('../models/garage');
const garageRoute = require('express').Router();


// Route to get all garages
garageRoute.get('/', async (req, res) => {
  try {
    const garages = await Garage.FindAllGarages();
    res.json(garages);
  } catch (error) {
    res.status(500).json({ error: 'Failed to retrieve garages' });
  }
});

// Route to get a specific garage by ID
garageRoute.get('/:id', async (req, res) => {
  try {
    const garage = await Garage.FindById(req.params.id);
    if (!garage) {
      res.status(404).json({ error: 'Garage not found' });
    } else {
      res.json(garage);
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to retrieve the garage' });
  }
});

garageRoute.post('/', async (req, res) => {
  const { name, longitude, latitude, city, address, garageCompany, phoneNumber, reviews } = req.body;

  try {
    const newGarage = new Garage();
    newGarage.name = name;
    newGarage.longitude = longitude;
    newGarage.latitude = latitude;
    newGarage.city = city;
    newGarage.address = address;
    newGarage.garageCompany = garageCompany;
    newGarage.phoneNumber = phoneNumber;
    newGarage.reviews = reviews; // Assign the reviews array to the new garage

    const result = await newGarage.InsertOne();
    res.status(201).json(result);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create a new garage with reviews' });
  }
});



// Route to delete a garage by ID
garageRoute.delete('/:id', async (req, res) => {
  try {
    const result = await Garage.DeleteById(req.params.id);
    if (result) {
      res.json({ message: 'Garage deleted successfully' });
    } else {
      res.status(404).json({ error: 'Garage not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete the garage' });
  }
});

module.exports = garageRoute;
