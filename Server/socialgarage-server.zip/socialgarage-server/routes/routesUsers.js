const User = require('../models/users');
const userRoute = require('express').Router();
const cloudinary = require("cloudinary").v2
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
const crypto = require('crypto');



// my server: https://socialgarage.onrender.com


cloudinary.config({
  cloud_name: 'dvstugwjr',
  api_key: '723597433638849',
  api_secret: 'qJylaxfKK3_OVuAsA3_F6MwzhqE'
});



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/:id/addcar', async (req, res) => {
  try {
    const { id } = req.params;
    const { car } = req.body;

    let user = await User.FindById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const userWithCar = await User.FindUserByCar(car);
    const admin = await User.FindById('64bf7b8016418c32d35e12d0'); // Assuming admin ID is known

    // Check if the car is with the admin and transfer it to the user
    if (userWithCar && userWithCar._id.toString() === admin._id.toString()) {
      const newCar = admin.cars.find((adminCar) => adminCar.carNumber === car.carNumber);
      admin.cars = admin.cars.filter((adminCar) => adminCar.carNumber !== car.carNumber);

      user.cars.push(newCar);

      // Update admin and user in the database
      await User.UpdateById(admin._id.toString(), admin);
      let updatedUser = await User.UpdateById(id, user);

      return res.status(200).json(updatedUser);
    } else if (userWithCar && userWithCar._id.toString() !== id) {
      return res.status(409).json({ error: 'Car already exists in another user' });
    }

    // If the car is not with the admin or another user, just add it to the current user
    user.cars.push(car);
    let updatedUser = await User.UpdateById(id, user);
    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/upload', async (req, res) => {
  try {
    let { image } = req.body;
    let imageData = 'data:image/jpeg;base64,' + image;

    cloudinary.uploader.upload_large(imageData, (err, url) => {
      if (err) {
        console.error(err);
      }
      res.status(200).json(url.secure_url);
    });

  } catch (error) {
    res.status(500).json({ error });
  }
});


function uploadToCloudinary(image) {
  return new Promise((resolve, reject) => {
    cloudinary.v2.uploader.upload_large(image, (err, url) => {
      if (err) return reject(err);
      return resolve(url);
    })
  });
}


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.get('/', async (req, res) => {
  try {
    let data = await User.FindAllUsers();
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.get('/allCars', async (req, res) => {
  try {
    let allCars = [];

    // Get all users from the database
    const allUsers = await User.FindAllUsers();

    allUsers.forEach((user) => {
      user.cars.forEach((car) => {
        allCars.push(car);
      });
    });

    res.status(200).json(allCars);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.get('/:id', async (req, res) => {
  try {
    let { id } = req.params;
    let data = await User.FindById(id);
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error });
  }
});



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/add', async (req, res) => {
  try {
    let { email, name, password, profileImage, followers, following, cars } = req.body;

    // Check if user with the same email already exists
    let existingUser = await User.FindByEmail(email);
    if (existingUser) {
      return res.status(408).json({ error: 'User with the same email already exists' });
    }

    // Check if user with the same name already exists
    let existingUserName = await User.FindByName(name);
    if (existingUserName) {
      return res.status(409).json({ error: 'User with the same name already exists' });
    }

    let user = new User(email, name, password, profileImage, followers, following, cars);
    let data = await user.InsertOne();
    res.status(201).json(data);
  } catch (error) {
    res.status(500).json({ error });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

// Example login route
userRoute.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find the user by email
    const user = await User.FindByEmail(email);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Compare the provided password with the hashed password in the database
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Authentication successful
    // Here you can generate a token or maintain a session to keep the user logged in
    // Return the user information without the "message" field

    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error });
  }
});


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


userRoute.get('/getUserIdAndNameByEmail/:email', async (req, res) => {
  try {
    const { email } = req.params;

    // Find the user by email
    const user = await User.FindByEmail(email);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Extract the _id and name from the user object
    const { _id, name, profileImage } = user;

    res.status(200).json({ _id, name, profileImage });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});




/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.put('/:id/mileage', async (req, res) => {
  try {
    let { id } = req.params;
    let { carNumber, mileage } = req.body;

    let user = await User.FindById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Update the mileage of the car with the given id
    user.cars.forEach((car) => {
      if (car.carNumber === carNumber) {
        car.currentMileage = mileage;
      }
    });

    // Update the user document in the database
    let updatedUser = await User.UpdateById(id, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error });
  }
});


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.put('/:id/test', async (req, res) => {
  try {
    let { id } = req.params;
    let { carNumber, testValidity } = req.body;

    let user = await User.FindById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Update the test validity of the car with the given id
    user.cars.forEach((car) => {
      if (car.carNumber === carNumber) {
        car.testValidity = testValidity;
      }
    });

    // Update the user document in the database
    let updatedUser = await User.UpdateById(id, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/:id/addMaintenance', async (req, res) => {
  try {
    let { id } = req.params;
    let { carNumber, newMaintenance } = req.body;

    let user = await User.FindById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car with the given carNumber
    let car = user.cars.find((car) => car.carNumber === carNumber);
    if (!car) {
      return res.status(404).json({ error: 'Car not found' });
    }

    // Add the new maintenance to the car
    car.tahzuka.push(newMaintenance);

    // Update the user document in the database
    let updatedUser = await User.UpdateById(id, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/:id/transferCar', async (req, res) => {
  try {
    const { id } = req.params;
    const { email, carNumber } = req.body;

    const user = await User.FindById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const carToTransfer = user.cars.find((car) => car.carNumber === carNumber);
    if (!carToTransfer) {
      return res.status(404).json({ error: 'Car not found' });
    }

    const newOwner = await User.FindByEmail(email);
    if (!newOwner) {
      return res.status(404).json({ error: 'New owner not found' });
    }
    carToTransfer.ownerName = newOwner.name;

    newOwner.cars.push(carToTransfer);
    user.cars = user.cars.filter((car) => car.carNumber !== carNumber);

    const updatedUser = await User.UpdateById(id, user);
    const updatedNewOwner = await User.UpdateByEmail(email, newOwner);

    res.status(200).json({ updatedUser, updatedNewOwner });


    res.status(200).json(updatedNewOwner);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


userRoute.put('/:carNumber/updateCards', async (req, res) => {
  try {
    const { carNumber } = req.params;
    const { newOwnerId, newOwnerName, newProfileImage } = req.body;

    // Find the user who owns the car with the specified carNumber
    const userWithCar = await User.FindUserByCar({ carNumber });

    if (!userWithCar) {
      return res.status(404).json({ error: 'Car not found' });
    }

    // Find the car with the specified carNumber
    const car = userWithCar.cars.find((car) => car.carNumber === carNumber);

    if (!car) {
      return res.status(404).json({ error: 'Car not found for the user' });
    }

    // Update each card's owner information with the new values
    car.cards.forEach((card) => {
      card.owner.id = newOwnerId;
      card.owner.name = newOwnerName;
      card.owner.profileImage = newProfileImage;
    });

    // Update the user document in the database
    const updatedUser = await User.UpdateById(userWithCar._id, userWithCar);

    res.status(200).json({ message: 'Card ownership updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/sendMailWithKey', async (req, res) => {
  try {
    const { email } = req.body;

    // Create a random number or string that you want to send in the email
    const randomKey = crypto.randomBytes(10).toString('hex');

    // Configure the transporter to send emails (Update this with your email credentials)
    const transporter = nodemailer.createTransport({
      service: 'gmail', // Change this to your email provider (e.g., 'hotmail', 'yahoo', etc.)
      auth: {
        user: 'asafmahluf2@gmail.com',
        pass: 'foblcejshwktdlvh',
      },
    });

    // Email content using HTML formatting
    const mailOptions = {
      from: 'your_email@gmail.com', // Update with your email
      to: email,
      subject: 'Your Random Key', // Update the subject as you like
      html: `
        <div style="background-color: #f2f2f2; padding: 20px;">
          <img src="https://example.com/logo.png" alt="Logo" style="display: block; margin: 0 auto;">
          <h1 style="color: #007bff; text-align: center; font-family: Arial, sans-serif;">Hello!</h1>
          <p style="text-align: center; font-family: Arial, sans-serif; font-size: 18px;">Thank you for using our service.</p>
          <div style="text-align: center;">
            <strong style="font-size: 24px; color: #28a745;">Here is your random key:</strong>
            <p style="font-size: 30px; color: #dc3545; animation: shake 1s infinite;">${randomKey}</p>
          </div>
          <p style="text-align: center; font-family: Arial, sans-serif; font-size: 18px;">Keep it safe and use it wisely!</p>
          <p style="text-align: center; font-family: Arial, sans-serif; font-size: 18px;">Best regards,</p>
          <p style="text-align: center; font-family: Arial, sans-serif; font-size: 18px;">Social garage Ⓒ</p>
        </div>

        <style>
          @keyframes shake {
            0% { transform: translateX(0); }
            25% { transform: translateX(-10px) rotate(-2deg); }
            50% { transform: translateX(10px) rotate(2deg); }
            75% { transform: translateX(-5px) rotate(-1deg); }
            100% { transform: translateX(5px) rotate(1deg); }
          }
        </style>
      `,
    };

    // Send the email
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
        return res.status(500).json({ error: 'An error occurred while sending the email' });
      }
      console.log('Email sent:', info.response);
      res.status(200).json({ key: randomKey }); // Return the key to the client
    });

  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});
/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



userRoute.post('/:id/addCardToCar', async (req, res) => {
  try {
    let { id } = req.params;
    let { carNumber, newCard } = req.body;

    let user = await User.FindById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    let car = user.cars.find((car) => car.carNumber === carNumber);
    if (!car) {
      return res.status(404).json({ error: 'Car not found' });
    }

    car.cards.push(newCard);

    // Update the user document in the database
    let updatedUser = await User.UpdateById(id, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});
/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/:id/makeCarPublic/:carNumber', async (req, res) => {
  try {
    const { id, carNumber } = req.params;

    // Find the user by id
    const user = await User.FindById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car by carNumber
    const carIndex = user.cars.findIndex((car) => car.carNumber === carNumber);
    if (carIndex === -1) {
      return res.status(404).json({ error: 'Car not found' });
    }

    // Set isPrivate to false
    user.cars[carIndex].isPrivate = false;

    // Update the user document in the database
    const updatedUser = await User.UpdateById(id, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});

userRoute.post('/:id/makeCarPrivate/:carNumber', async (req, res) => {
  try {
    const { id, carNumber } = req.params;

    // Find the user by id
    const user = await User.FindById(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car by carNumber
    const carIndex = user.cars.findIndex((car) => car.carNumber === carNumber);
    if (carIndex === -1) {
      return res.status(404).json({ error: 'Car not found' });
    }

    // Set isPrivate to false
    user.cars[carIndex].isPrivate = true;

    // Update the user document in the database
    const updatedUser = await User.UpdateById(id, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/:ownerId/:carNumber/increaseLikes/:cardId/:userId', async (req, res) => {
  try {
    const { ownerId, carNumber, cardId, userId } = req.params;

    const user = await User.FindById(ownerId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    const car = user.cars.find((car) => car.carNumber === carNumber);
    if (!car) {
      return res.status(404).json({ error: 'Car not found' });
    }
    const card = car.cards.find((card) => card._id === cardId);
    if (!card) {
      return res.status(404).json({ error: 'Card not found' });
    }

    const userIndex = card.likedBy.indexOf(userId);

    if (userIndex !== -1) {
      // User has already liked the card, remove like
      card.likes -= 1;
      card.likedBy.splice(userIndex, 1);
    } else {
      // User hasn't liked the card, add like
      card.likes += 1;
      card.likedBy.push(userId);
    }

    await User.UpdateById(ownerId, user);

    res.status(200).json({ user, updatedCard });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.get('/:userId/public-cars', async (req, res) => {
  try {
    const { userId } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Filter user's cars to get only the public ones
    const publicCars = user.cars.filter((car) => !car.isPrivate);

    res.status(200).json(publicCars);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/:userId/:carNumber/:cardId/add-comment', async (req, res) => {
  try {
    const { userId, carNumber, cardId } = req.params;
    const { userName, comment } = req.body;

    const user = await User.AddCommentToCard(userId, carNumber, cardId, userName, comment);

    res.status(200).json(user);
  } catch (error) {
    console.error('Failed to add comment:', error);
    res.status(500).json({ error: 'An error occurred while adding the comment' });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.get('/search/:name', async (req, res) => {
  try {
    const { name } = req.params;

    // Find users by name (assuming you have a method in your User model to do this)
    const users = await User.FindUsersByName(name);

    if (!users || users.length === 0) {
      return res.status(404).json({ error: 'No users found' });
    }

    res.status(200).json(users);
  } catch (error) {
    console.error('Failed to search users:', error);
    res.status(500).json({ error: 'An error occurred while searching for users' });
  }
});

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

userRoute.post('/:userId/follow/:userIdToFollow', async (req, res) => {
  try {
    const { userId, userIdToFollow } = req.params;

    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    await User.Follow(userId, userIdToFollow);

    res.status(200).json({ message: 'Successfully followed user' });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});

userRoute.post('/:userId/unfollow/:userIdToUnfollow', async (req, res) => {
  try {
    const { userId, userIdToUnfollow } = req.params;

    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    await User.Unfollow(userId, userIdToUnfollow);

    res.status(200).json({ message: 'Successfully unfollowed user' });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});



/************************************************כמות עוקבים**********************************************************/

userRoute.get('/:userId/followers/count', async (req, res) => {
  try {
    const { userId } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get the number of followers from the user's followers array
    const followersCount = user.followers.length;

    res.status(200).json({ count: followersCount });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


userRoute.get('/:userId/following/count', async (req, res) => {
  try {
    const { userId } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get the number of users being followed by the user
    const followingCount = user.following.length;

    res.status(200).json({ count: followingCount });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});
/**********************************************************************************************************************/

/****************** בדיקת עוקב או לא עוקב *******************/
userRoute.get('/:userId/following/:userIdToCheck', async (req, res) => {
  try {
    const { userId, userIdToCheck } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check if the user with userIdToCheck is being followed by the user
    const isFollowing = user.following.some(followedUser => followedUser._id === userIdToCheck);

    res.status(200).json({ isFollowing });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});



userRoute.get('/:userId/following', async (req, res) => {
  try {
    const { userId } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get the list of users being followed by the user
    const followingUsers = user.following;

    res.status(200).json(followingUsers);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});

// Route to get the list of users who are following the current user
userRoute.get('/:userId/followers', async (req, res) => {
  try {
    const { userId } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get the list of followers for the user
    const followerUsers = user.followers;

    res.status(200).json(followerUsers);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


/**********************************************************************************************************************/
/****************** Total Likes of user *******************/

userRoute.get('/:userId/sum-likes', async (req, res) => {
  try {
    const { userId } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    let totalLikes = 0;

    // Loop through the user's cars and their cards to calculate total likes
    user.cars.forEach((car) => {
      car.cards.forEach((card) => {
        totalLikes += card.likes;
      });
    });

    res.status(200).json({ totalLikes });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


/****************** Total Likes of car *******************/
userRoute.get('/total-likes/:carNumber', async (req, res) => {
  try {
    const { carNumber } = req.params;

    // Find the user with the car
    const userWithCar = await User.FindUserByCar({ carNumber });

    if (!userWithCar) {
      return res.status(404).json({ error: 'Car not found' });
    }

    // Find the car with the specified carNumber
    const car = userWithCar.cars.find((car) => car.carNumber === carNumber);

    if (!car) {
      return res.status(404).json({ error: 'Car not found for the user' });
    }

    let totalLikes = 0;

    // Loop through the car's cards to calculate total likes
    car.cards.forEach((card) => {
      totalLikes += card.likes;
    });

    res.status(200).json({ totalLikes });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SALE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */



userRoute.post('/:userId/addSaleDetails', async (req, res) => {
  try {
    const { userId } = req.params;
    const { carNumber, price, detailsOfSale } = req.body;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car with the specified carNumber
    const car = user.cars.find((car) => car.carNumber === carNumber);

    if (!car) {
      return res.status(404).json({ error: 'Car not found for the user' });
    }

    // Add the sale details to the car
    car.price = price;
    car.detailsOfSale = detailsOfSale;
    car.isForSale = true;
    car.isPrivate = false;


    // Update the user document in the database
    const updatedUser = await User.UpdateById(userId, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});



userRoute.post('/:userId/removeSaleDetails/:carNumber', async (req, res) => {
  try {
    const { userId, carNumber } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car with the specified carNumber
    const car = user.cars.find((car) => car.carNumber === carNumber);

    if (!car) {
      return res.status(404).json({ error: 'Car not found for the user' });
    }

    // Remove the sale details from the car and set isForSale to false
    car.price = null;
    car.detailsOfSale = null;
    car.isForSale = false;

    // Update the user document in the database
    const updatedUser = await User.UpdateById(userId, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});



userRoute.get('/getUserIdByCarNumber/:carNumber', async (req, res) => {
  try {
    const { carNumber } = req.params;

    // Find the user who owns the car with the specified carNumber
    const userWithCar = await User.FindUserByCar({ carNumber });

    if (!userWithCar) {
      return res.status(404).json({ error: 'Car not found' });
    }

    // Get the user's ID
    const ownerId = userWithCar._id;

    res.status(200).json({ ownerId });
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


userRoute.get('/getFullUserByCarNumber/:carNumber', async (req, res) => {
  try {
    const { carNumber } = req.params;

    // Find the user who owns the car with the specified carNumber
    const userWithCar = await User.FindUserByCar({ carNumber });

    if (!userWithCar) {
      return res.status(404).json({ error: 'Car not found' });
    }

    res.status(200).json(userWithCar);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


userRoute.put('/:userId/editSaleDetails/:carNumber', async (req, res) => {
  try {
    const { userId, carNumber } = req.params;
    const { price, detailsOfSale } = req.body;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car with the specified carNumber
    const car = user.cars.find((car) => car.carNumber === carNumber);

    if (!car) {
      return res.status(404).json({ error: 'Car not found for the user' });
    }

    // Update the sale details of the car
    car.price = price;
    car.detailsOfSale = detailsOfSale;

    // Update the user document in the database
    const updatedUser = await User.UpdateById(userId, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


userRoute.get('/:carNumber/cards', async (req, res) => {
  try {
    const { carNumber } = req.params;

    // Find the user who owns the car with the specified carNumber
    const userWithCar = await User.FindUserByCar({ carNumber });

    if (!userWithCar) {
      return res.status(404).json({ error: 'Car not found' });
    }

    // Find the car with the specified carNumber
    const car = userWithCar.cars.find((car) => car.carNumber === carNumber);

    if (!car) {
      return res.status(404).json({ error: 'Car not found for the user' });
    }

    // Get the cards of the car
    const cards = car.cards;

    res.status(200).json(cards);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});



userRoute.post('/:cardId/updateImageBio', async (req, res) => {
  try {
    const { cardId } = req.params;
    const { newImageBio } = req.body;


    // Find the user by userId
    const user = await User.FindById(newImageBio.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car with the specified carNumber
    const car = user.cars.find((car) => car.carNumber === newImageBio.carNumber);

    if (!car) {
      return res.status(404).json({ error: 'Car not found for the user' });
    }

    const card = car.cards.find((card) => card._id === cardId);

    if (!card) {
      return res.status(404).json({ error: 'Card not found for the user' });
    }

    card.imageBio = newImageBio.imageBio;

    // Update the user document in the database
    const updatedUser = await User.UpdateById(newImageBio.userId, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


userRoute.delete('/:userId/removeCard/:cardId', async (req, res) => {
  try {
    const { userId, cardId } = req.params;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car that contains the card with the specified cardId
    let carContainingCard = null;
    user.cars.forEach((car) => {
      const cardIndex = car.cards.findIndex((card) => card._id === cardId);
      if (cardIndex !== -1) {
        carContainingCard = car;
        carContainingCard.cards.splice(cardIndex, 1); // Remove the card from the car's cards array
      }
    });

    if (!carContainingCard) {
      return res.status(404).json({ error: 'Card not found for the user' });
    }

    // Update the user document in the database
    const updatedUser = await User.UpdateById(userId, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});


userRoute.put('/:userId/updateCarImage/:carNumber', async (req, res) => {
  try {
    const { userId, carNumber } = req.params;
    const { image } = req.body;

    // Find the user by userId
    const user = await User.FindById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Find the car with the specified carNumber
    const car = user.cars.find((car) => car.carNumber === carNumber);

    if (!car) {
      return res.status(404).json({ error: 'Car not found for the user' });
    }

    car.image = image;

    // Update the user document in the database
    const updatedUser = await User.UpdateById(userId, user);

    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred' });
  }
});







module.exports = userRoute;