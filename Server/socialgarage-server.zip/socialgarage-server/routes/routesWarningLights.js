const WarningLight = require('../models/warningLights');
const warningLightRoute = require('express').Router();

warningLightRoute.get('/', async (req, res) => {
  try {
    let data = await WarningLight.FindAllWarningLights();
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error });
  }
});

warningLightRoute.get('/:lightCode', async (req, res) => {
  try {
    let { lightCode } = req.params;
    let data = await WarningLight.FindByLightCode(lightCode);
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error });
  }
});

warningLightRoute.post('/add', async (req, res) => {
  try {
    let { lightCode, lightDescription, riskLevel, lightImage } = req.body;
    let data = await new WarningLight(lightCode, lightDescription, riskLevel, lightImage).InsertOne();
    res.status(201).json(data);
  } catch (error) {
    res.status(500).json({ error });
  }
});

module.exports = warningLightRoute;
