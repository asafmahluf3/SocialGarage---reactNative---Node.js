const { MongoClient, ObjectId } = require('mongodb');

class DB {
    client;
    dbName;

    constructor() {
        this.client = new MongoClient(process.env.DB_URI);
        this.dbName = process.env.DB_NAME;
    }

    async connect() {
        try {
            await this.client.connect();
            console.log('Connected to the database');
        } catch (error) {
            console.error('Failed to connect to the database:', error);
        }
    }


    async FindAll(collection, query = {}, projection = {}) {
        try {
            return await this.client
                .db(this.dbName)
                .collection(collection)
                .find(query, projection)
                .toArray();
        } catch (error) {
            console.error('Failed to fetch documents:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }

    async FindByID(collection, id) {
        try {
            return await this.client
                .db(this.dbName)
                .collection(collection)
                .findOne({ _id: new ObjectId(id) });
        } catch (error) {
            console.error('Failed to fetch document by ID:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }


    async FindByCardID(collection, id) {
        try {
            return await this.client
                .db(this.dbName)
                .collection(collection)
                .findOne({ _id: id });
        } catch (error) {
            console.error('Failed to fetch document by ID:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }

    async Insert(collection, doc) {
        try {
            const result = await this.client
                .db(this.dbName)
                .collection(collection)
                .insertOne(doc);
            return result.ops[0];
        } catch (error) {
            console.error('Failed to insert document:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }

    async InsertMany(collection, docs) {
        try {
            const result = await this.client
                .db(this.dbName)
                .collection(collection)
                .insertMany(docs);
            return result.ops;
        } catch (error) {
            console.error('Failed to insert documents:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }

    async close() {
        try {
            await this.client.close();
            console.log('Closed the database connection');
        } catch (error) {
            console.error('Failed to close the database connection:', error);
        }
        finally {
            await this.close();
        }
    }



    async FindOne(collection, query, projection = {}) {
        try {
            return await this.client
                .db(this.dbName)
                .collection(collection)
                .findOne(query, projection);
        } catch (error) {
            console.error('Failed to fetch document:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }


    async UpdateById(collection, id, updatedData) {
        try {
            const result = await this.client
                .db(this.dbName)
                .collection(collection)
                .updateOne({ _id: new ObjectId(id) }, { $set: updatedData });

            if (result.modifiedCount === 0) {
                throw new Error('Failed to update document');
            }

            return updatedData;
        } catch (error) {
            console.error('Failed to update document:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }

    async UpdateByCardId(collection, id, updatedData) {
        try {
            const result = await this.client
                .db(this.dbName)
                .collection(collection)
                .updateOne({ _id: id }, { $set: updatedData });

            if (result.modifiedCount === 0) {
                throw new Error('Failed to update document');
            }

            return updatedData;
        } catch (error) {
            console.error('Failed to update document:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }


    async UpdateByEmail(collection, email, updatedData) {
        try {
            const result = await this.client
                .db(this.dbName)
                .collection(collection)
                .updateOne({ email }, { $set: updatedData });

            if (result.modifiedCount === 0) {
                throw new Error('Failed to update document');
            }

            return updatedData;
        } catch (error) {
            console.error('Failed to update document:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }


    async DeleteMany(collection, query) {
        try {
            const result = await this.client
                .db(this.dbName)
                .collection(collection)
                .deleteMany(query);

            return result.deletedCount;
        } catch (error) {
            console.error('Failed to delete documents:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }

    async Find(collection, query = {}, projection = {}) {
        try {
            return await this.client
                .db(this.dbName)
                .collection(collection)
                .find(query, projection)
                .toArray();
        } catch (error) {
            console.error('Failed to fetch documents:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }


    async FindMany(collection, query = {}, projection = {}) {
        try {
            return await this.client
                .db(this.dbName)
                .collection(collection)
                .find(query, projection)
                .toArray();
        } catch (error) {
            console.error('Failed to fetch documents:', error);
            return error;
        }
        finally {
            await this.close();
        }
    }


    // Inside your DB class definition
    async DeleteOne(collection, query) {
        try {
            const result = await this.client
                .db(this.dbName)
                .collection(collection)
                .deleteOne(query);

            return result.deletedCount === 1;
        } catch (error) {
            console.error('Failed to delete document:', error);
            return false;
        }
    }




    async close() {
        try {
            await this.client.close();
            console.log('Closed the database connection');
        } catch (error) {
            console.error('Failed to close the database connection:', error);
        }
    }



}

module.exports = DB;