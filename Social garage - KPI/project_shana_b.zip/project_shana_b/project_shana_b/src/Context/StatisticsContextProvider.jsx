import React, { createContext, useEffect, useState } from 'react';

export const StatisticsContext = createContext();

const StatisticsContextProvider = (props) => {
  const [statisticsUsers, setStatisticsUsers] = useState([]);

  useEffect(() => {
    // Fetch the users from the server
    fetch('https://socialgarage.onrender.com/api/users') // Replace this URL with the appropriate endpoint on your server
      .then((response) => response.json())
      .then((data) => setStatisticsUsers(data))
      .catch((error) => console.error('Error fetching users:', error));
  }, []);

  return (
    <StatisticsContext.Provider value={{ statisticsUsers, setStatisticsUsers }}>
      {props.children}
    </StatisticsContext.Provider>
  );
};

export default StatisticsContextProvider;
