import React from 'react'
import { Route, Routes } from 'react-router-dom'
import FCLogin from '../Pages/FCLogin'
import FCHomePage from '../Pages/FCHomePage'
import FCTables from '../Pages/FCTables'





export default function FCRoutes() {
    return (
        <div style={{ margin: 20, fontSize: 25, color: 'red' }}>
            <Routes>
                <Route path='/' element={<FCLogin />} />
                <Route path='/homepage' element={<FCHomePage />} />
                <Route path='/tables' element={<FCTables />} />

                {/* <Route path='/profile' element={<FCProfile />} /> */}
                {/* <Route path='/carstatistic' element={<FCCars />} /> */}
            </Routes>
        </div>
    )
}
