import React, { useContext } from 'react';
import { UserContext } from '../Context/UserContextProvider';
import { StatisticsContext } from '../Context/StatisticsContextProvider';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  LineChart,
  Line,
} from 'recharts';

export default function FCHomePage() {
  const { } = useContext(UserContext);
  const { statisticsUsers } = useContext(StatisticsContext);

  const userCarData = statisticsUsers.map((user) => ({
    username: user.name,
    carCount: user.cars.length,
  }));

  const getCarStatisticsByManufacturer = () => {
    const carStatisticsByManufacturer = {};

    statisticsUsers.forEach((user) => {
      user.cars.forEach((car) => {
        const manufacturer = car.manufacturer;

        if (carStatisticsByManufacturer[manufacturer]) {
          carStatisticsByManufacturer[manufacturer]++;
        } else {
          carStatisticsByManufacturer[manufacturer] = 1;
        }
      });
    });

    const carStatisticsData = Object.keys(carStatisticsByManufacturer).map((manufacturer) => ({
      manufacturer,
      carCount: carStatisticsByManufacturer[manufacturer],
    }));

    return carStatisticsData;
  };

  const getCarStatisticsByModel = () => {
    const carStatisticsByModel = {};

    statisticsUsers.forEach((user) => {
      user.cars.forEach((car) => {
        const manufacturer = car.manufacturer;
        const model = car.model;

        if (!carStatisticsByModel[manufacturer]) {
          carStatisticsByModel[manufacturer] = {};
        }

        if (carStatisticsByModel[manufacturer][model]) {
          carStatisticsByModel[manufacturer][model]++;
        } else {
          carStatisticsByModel[manufacturer][model] = 1;
        }
      });
    });

    const carStatisticsByModelData = [];

    // Convert nested data to a flat array for pies
    for (const manufacturer in carStatisticsByModel) {
      for (const model in carStatisticsByModel[manufacturer]) {
        carStatisticsByModelData.push({
          manufacturer,
          model,
          carCount: carStatisticsByModel[manufacturer][model],
        });
      }
    }

    return carStatisticsByModelData;
  };

  const getCarStatisticsByYear = () => {
    const carStatisticsByYear = {};

    statisticsUsers.forEach((user) => {
      user.cars.forEach((car) => {
        const year = car.year;

        if (carStatisticsByYear[year]) {
          carStatisticsByYear[year]++;
        } else {
          carStatisticsByYear[year] = 1;
        }
      });
    });

    const carStatisticsByYearData = Object.keys(carStatisticsByYear).map((year) => ({
      year,
      carCount: carStatisticsByYear[year],
    }));

    return carStatisticsByYearData;
  };

  const carStatisticsData = getCarStatisticsByManufacturer();
  const carStatisticsByModelData = getCarStatisticsByModel();
  const carStatisticsByYearData = getCarStatisticsByYear();





  const luxuriousPageStyle = {
    fontFamily: 'YourLuxuryFont, sans-serif', // Replace 'YourLuxuryFont' with an actual luxury font
    background: 'url("luxury-background.jpg")', // Replace with your luxury background image
    color: '#ffffff', // Text color
    padding: '20px', // Spacing
  };

  const luxuriousHeaderStyle = {
    fontSize: '36px', // Title font size
    borderBottom: '2px solid #A4E287', // Title underline
    paddingBottom: '10px', // Spacing below title
  };

  const luxuriousChartStyle = {
    background: 'rgba(255, 255, 255, 0.1)', // Chart background with transparency
    padding: '20px', // Spacing around charts
    marginBottom: '20px', // Spacing between charts
    borderRadius: '10px', // Rounded corners
  };

  return (
    <div style={luxuriousPageStyle}>
      <div style={luxuriousHeaderStyle}>
        <h1>סטטיסטיקת רכבים</h1>
      </div>
      <div style={luxuriousChartStyle}>
        <h2>Number of Cars Owned by Users</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={userCarData}>
            <XAxis dataKey="username" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="carCount" fill="#A4E287" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div style={luxuriousChartStyle}>
        <h2>Number of Cars by Manufacturer</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={carStatisticsData}>
            <XAxis dataKey="manufacturer" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="carCount" fill="#A4E287" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div style={luxuriousChartStyle}>
        <h2>Number of Cars by Year</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={carStatisticsByYearData}>
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="carCount" fill="#A4E287" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {carStatisticsData.map((manufacturerData) => {
        const modelsData = carStatisticsByModelData.filter(
          (modelData) => modelData.manufacturer === manufacturerData.manufacturer
        );

        // Calculate the sum of car models for this manufacturer
        const totalModels = modelsData.reduce((sum, modelData) => sum + modelData.carCount, 0);

        return (
          <div key={manufacturerData.manufacturer} style={luxuriousChartStyle}>
            <h2>Car Models by {manufacturerData.manufacturer}</h2>
            <ResponsiveContainer width="100%" height={350}>
              <PieChart>
                <Pie
                  dataKey="carCount"
                  nameKey="model"
                  data={modelsData}
                  fill="#A4E287"
                  label
                />
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>

            {/* Display the total count of car models for this manufacturer */}
            <div style={{ textAlign: 'center', marginTop: '10px', color: '#A4E287' }}>
              <span>Sum: {totalModels}</span>
            </div>
          </div>
        );
      })}






      {/* Add more charts or components as needed */}
    </div>
  );
}
