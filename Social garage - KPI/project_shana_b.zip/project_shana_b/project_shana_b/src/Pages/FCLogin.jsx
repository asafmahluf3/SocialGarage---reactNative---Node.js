import { Button, Snackbar, TextField, Typography } from '@mui/material'
import React, { useContext, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { UserContext } from '../Context/UserContextProvider'

export default function FCLogin() {
  const [userEmailLogin, setuserNameLogin] = useState('')
  const [passwordLogin, setPasswordLogin] = useState('')
  const { users, setcurrentUser, fromLoginToCheckIfExist, setloginOrProfile, setadminIsConnect } = useContext(UserContext)
  const navigate = useNavigate()

  const [open, setOpen] = useState(false)
  const [message, setMessage] = useState('')

  // ---------- Click Login
  const btnLoginPress = () => {
    let userCheckExist = fromLoginToCheckIfExist(userEmailLogin, passwordLogin)
    console.log(userCheckExist)
    if (userCheckExist !== null && userCheckExist !== undefined) {
      setMessage('Welcome')
      setOpen(true)
      setloginOrProfile("/profile")
      setcurrentUser(userCheckExist)
      navigate("/homepage")
      if (userEmailLogin === "yair161643@gmail.com" || userEmailLogin === "asafmahluf2@gmail.com") {
        setadminIsConnect(true)
      }
    }
    else {
      setMessage("We don't know you")
      setOpen(true)
    }
  }

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return
    }
    setOpen(false)
  }

  return (
    <div style={{ width: '700px', background: "linear-gradient(to right, rgb(255, 255, 255), #835B00)", padding: "20px", borderRadius: "10px", boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" }}>
      <Typography variant="h3" style={{ color: "lightblue", textAlign: "center", marginBottom: "30px" }}>𝓛𝓸𝓰𝓲𝓷</Typography>

      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
        <TextField style={{ width: '50%', marginBottom: '15px' }} id="outlined-basic" label="Email" variant="outlined" onChange={(e) => setuserNameLogin(e.target.value)} />
        <TextField style={{ width: '50%', marginBottom: '15px' }} type={"password"} id="outlined-basic" label="Password" variant="outlined" onChange={(e) => setPasswordLogin(e.target.value)} />
        <Button variant="contained" style={{ width: '50%', background: "#835B00", color: "white" }} onClick={btnLoginPress}>Login</Button>
      </div>

      <Snackbar
        style={{ marginTop: '20px' }}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        open={open}
        autoHideDuration={1000}
        onClose={handleClose}
        message={message}
      />


    </div>
  )
}
