import React, { useContext } from 'react';
import { UserContext } from '../Context/UserContextProvider';
import { StatisticsContext } from '../Context/StatisticsContextProvider';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

import './Profile.css';

export default function FCTables() {
    const { } = useContext(UserContext);
    const { statisticsUsers } = useContext(StatisticsContext);
    const numUsers = statisticsUsers.length;

    // Calculate the total number of cars in the system
    const totalCarsCount = statisticsUsers.reduce(
        (total, user) => total + user.cars.length,
        0
    );



    return (
        <div>
            <div className="user-table-container">
                <h2>Users Details</h2>
                <table className="user-table" style={{ color: "#A4E287" }}>
                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Car Count</th>
                            <th>Cars numbers</th>
                        </tr>
                    </thead>
                    <tbody>
                        {statisticsUsers.map((user) => (
                            <tr key={user._id}>
                                <td>{user.email}</td>
                                <td>{user.name}</td>
                                <td>{user.cars.length}</td>

                                <td>
                                    {user.cars.map((car) => (
                                        <div key={car.carNumber}>{car.carNumber}</div>
                                    ))}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <div className="user-counter">
                    Total users: {numUsers}
                </div>
            </div>




            <div className="car-table-container">
                <h2>Cars Details</h2>
                <table className="user-table" style={{ color: "#A4E287" }}>
                    <thead>
                        <tr>
                            <th>Owner Email</th>
                            <th>Car Manufacturer</th>
                            <th>Car Model</th>
                            <th>Car Number</th>
                            <th>Year</th>
                            <th>hand</th>
                            <th>Mileage</th>
                            <th>Test</th>
                            <th>Nick name</th>

                        </tr>
                    </thead>
                    <tbody>
                        {statisticsUsers.map((user) =>
                            user.cars.map((car) => (
                                <tr key={car.carNumber}>
                                    <td>{user.email}</td>
                                    <td>{car.manufacturer}</td>
                                    <td>{car.model}</td>
                                    <td>{car.carNumber}</td>
                                    <td>{car.year}</td>
                                    <td>{car.hand}</td>
                                    <td>{car.currentMileage}</td>
                                    <td>{car.testValidity}</td>
                                    <td>{car.nickname}</td>

                                </tr>
                            ))
                        )}
                    </tbody>
                </table>


                <div className="user-counter">
                    Total cars: {totalCarsCount}
                </div>








            </div>
        </div>
    );
}
